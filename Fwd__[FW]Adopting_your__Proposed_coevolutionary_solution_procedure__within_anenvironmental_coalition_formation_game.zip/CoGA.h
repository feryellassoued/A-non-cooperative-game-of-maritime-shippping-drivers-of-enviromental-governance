#ifndef COGA_H
#define COGA_H
#include<vector>
#include <list>
#include <cmath>
#include"Terminal.h"
#include "ToroidalGrid.h"
//#define INTERGR_PRICE true
#define  FITNESSSHARING true
inline double RoundDouble(double var, int fixed = 2)
{
	// 37.66666 * 100 =3766.66
	// 3766.66 + .5 =37.6716    for rounding off value
	// then type cast to int so value is 3766
	// then divided by 100 so the value converted into 37.66
	double scale = std::pow(10, fixed);
	//std::cout << "scale " << scale << std::endl;
	double value = (int)(var * scale + 0.5);
	return (double)value / scale;
}


#define DECODE(v, lowerBound, upperBound) lowerBound + (upperBound - lowerBound)*v
//inline double DECODE(double v, double lowerBound, double upperBound)
//{
//	return lowerBound + (upperBound - lowerBound)*v;
//}
#define ENCODE(v, lowerBound, upperBound) (v-lowerBound) / (upperBound-lowerBound)
enum MutationPara
{
	_BitFlip=0,
	_RandomResetting,
	_Swap,
	_Scramble,
	_Inversion,
};
// more detail information:
//Practical Genetic Algorithms, Second Edition chapter 2
enum CrossOverPara
{

	_OnePoint=0,
	_MultiPoint,
	_Uniform,
	_WholeArithmeticRecombination,

};
enum ParentSelectionPara
{
	_RouletteWheel = 0,
	_Tournament,
	_Rank,
	_Elitism,
	_Random,
	_StochasticUniversalSampling,
};
enum ScopeofPartners
{
	_SE=0, // 	Entire population 
	_SN, //	3*3 Neighborhood 
};
enum PartnerSelectionRule
{
	_PB=0,// The best partner in the scope 
	_PPF, // A part of partners in the scope based on their fitness value 
	_PPR,// A part of partners in the scope in a random way 
	_PA,// 	All the partners in the scope and using the average value 
};
 
struct CoGAParameter
{
	CoGAParameter()
	{
		_ProMutation = 0.1;
		_ProCrossover = 0.8;
		_MaxIteration = 20000;
		_PopulationNum = 100;
		_GeneNum = 2;
		_PriceLowerBound = 0;
		_PriceUpperBound = 200;
		_FitnessWeight = 0.5;
		_Psi = 0.0001;
		_Zeta = 10;
		_ParentSelectionPara = ParentSelectionPara::_Rank;
		_CrossOverPara = CrossOverPara::_OnePoint;
		_MinOrMaxProblem = false;
		_MutationPara = MutationPara::_RandomResetting;
		 
		_ScopeofPartners = ScopeofPartners::_SN;
		_PartnerSelectionRule = PartnerSelectionRule::_PPF;
		_PartnerNum = 4;
	}
	double _ProMutation;
	double _ProCrossover;
	int _MaxIteration;
	int _PopulationNum;
	int _GeneNum;
	double _PriceLowerBound;// 20 US $
	double _PriceUpperBound;// 150 US $
	bool _MinOrMaxProblem;// if it is true, it is a minimize problem. Otherwise it is maximize problem
	double _FitnessWeight;
	double _Psi;
	int _Zeta;
	ParentSelectionPara _ParentSelectionPara;
	CrossOverPara _CrossOverPara;
	MutationPara _MutationPara;
	 
	ScopeofPartners _ScopeofPartners;
	PartnerSelectionRule _PartnerSelectionRule;
	int _PartnerNum;
};

class Individual
{
public:
	Individual();
	Individual(int index);
	Individual(Individual *indivdual);
	bool operator<(const Individual& indidual) const
	{
		return _Fitness < indidual._Fitness;
	}
	bool operator>(const Individual& indidual) const
	{
		return _Fitness > indidual._Fitness;
	}
	void PrintChromosome();
	void PrintFitness();
	void Copy(Individual individual);
	
public:
	std::vector<double> _Chromosome;
	int _NeighborLevel;
	int _BestPartnerCount;
	double _Fitness;
	double _FitnessShareing;
	double _Profit;
	std::vector<double> _ProfitVec;
	int _Index;// index in population
public:
	std::vector<double> Decode(double lowerBound, double upperBound);
	void SetChromosome(std::vector<double> chromosomeVec);
	void SetChromosome(std::vector<double> chromosomeVec, double lowerBound, double upperBound);
};
struct LSParameters
{
	LSParameters()
	{
		_StepSize = 0.1;
		_Length = 10.0;
	}
	LSParameters(double size, double length)
	{
		_StepSize = size;
		_Length = length;
	}
	double _StepSize;
	double _Length;
};
class CoGA;
class Species
{
public:
	Species(CoGAParameter* pParameter);
	Species(CoGAParameter* pParameter, int terminalIndex, CoGA * PCoGA);
public:
	void InitPopulations();
	void PrintChromosome();
	void PrintFitness();
	void CalculateProfit(int index);
	std::vector<double> CalculateProfitVec(int index);
	void InitFitness();
	std::vector<Individual> GetIndividuals(std::vector<int> individualId);
	std::pair<int, int>  UpdatePopulation(std::pair<Individual, Individual>offsprings, std::vector<int>  neighborhood, bool &improvementFlag);
	void UpdateProfit(int individualIndex, int geneId, Individual partnterIndividual);
	void UpdateProfit(int individualIndex);
	void UpdateFitness(int individualIndex);
	double CalculateFitness(int individualIndex);
	void InitFitness(int individualIndex);
	std::pair<double, double> FitnessMeanDeviation();
	void UpdateFitnessSumList();
	int WorseIndividualId();
	int BestIndividualId();
	double ChromosomeDeviation();
public:
	std::list<std::pair<double,double>> _FitnessMeanDeviastionList;// for each iteration 
	std::vector<Individual*> _Populations;
	int _TerminalIndex;
	PortPara  _PortPara;
	CoGAParameter* _pCoGAParameter;
	CoGA * _PCoGA;
	Individual* _BestIndividual;
	std::vector<Individual> _BestIndividualRecord;
	
};
typedef struct NonDominatedSortElement
{
	NonDominatedSortElement()
	{
		m_IndividualId = 0;
		m_DominatedByOtherIndividualNumber = 0;
		m_CrowdingDistance = .0;
	}
	 
	NonDominatedSortElement(int speciesId, int individualId)
	{
		m_SpeciesId = speciesId;
		m_IndividualId = individualId;
		m_DominatedByOtherIndividualNumber = 0;
		m_CrowdingDistance = .0;
	}
	int m_SpeciesId;
	int  m_IndividualId;
	int m_DominatedByOtherIndividualNumber;
	std::vector<int> m_DominatedElementId;
	double m_CrowdingDistance;
};
class PriceAndProfit
{
public:
	PriceAndProfit();	
	PriceAndProfit(PriceAndProfit * priceAndProfit);
	PriceAndProfit(int speciesid, int indId, double profit);
	PriceAndProfit(int speciesid, int indId, double profit, std::vector<double> profitVec);
	 
public:

	int _SpeciesId;
	int _IndividualId;
	 
	std::vector<double> _ProfitVec;
	double _Profit;
public:
	bool operator>(const PriceAndProfit& indidual) const
	{
		return _Profit> indidual._Profit;
	}
	bool operator<(const PriceAndProfit& indidual) const
	{
		return _Profit < indidual._Profit;
	}
};
//SimultaneousBiddingProcedure(SBP) :
class SBP 
{
public:
	SBP();
	 
	SBP(CoGAParameter*);
	 
	bool Negotiation(); 
	 
	void InitSolutionPool(std::vector<Species*> &peciesVec);
	void InitSolutionPool(std::vector<std::vector<Individual>> &peciesVec);
 
	bool AcceptPoolChecking(int populationId, int solutionId);
	 
	
public:
	std::vector<std::vector<PriceAndProfit>> _SolutionPool;
	std::vector<std::vector<PriceAndProfit>> _AcceptPool;
	 
	std::pair<int,int> _SpeciesIndividualId;
	
	CoGAParameter* _pCoGAParameter;
};
class CoGA
{
public:
	CoGA();
	~CoGA();
public:
	void InitCoGAParameter();
	void InitCoGAParameter(CoGAParameter* pCoGAParameter);
	void InitTerminals(std::vector<Terminal> terminals);
	void InitSpecies();
	std::pair<int, int> PartensSelection( std::vector<Individual> candidateIndividuals);
	std::pair<int, int> PSRankMethod(std::vector<Individual> candidateIndividuals);
	std::pair<int, int> RouletteWheel(std::vector<Individual> candidateIndividuals);
	int RouletteSelect(std::vector<double> weight);
	std::pair<Individual, Individual> CrossOver(Individual father, Individual mother, int geneIdex);
	std::pair<Individual, Individual> CrossOverOnePoint(Individual father, Individual mother, int geneIdex);
	void Mutation(Individual & Individual, int geneIdex);
	void MutationRandomResetting(Individual & Individual, int geneIdex);
	void Mutation(int speciesId, int individualIdex);
	void MutationRandomResetting(int speciesId, int individualIdex);
	Individual SelectBestFitness(std::vector<Individual> vec);
	std::vector<Individual> SelectBestFitnessRanking(std::vector<Individual> vec, bool asceding=true);
	std::vector<Individual> SelectBestFitnessRouletteWheel(std::vector<Individual> vec,int numberIndividual);
	std::vector<Individual> SelectBestFitnessRandomly(std::vector<Individual> vec, int numberIndividual);
	std::pair<int, int> UpdatePopulation(int speciesId, std::pair<Individual, Individual>offsprings, std::vector<int>  neighborhood);
	//void NashEquilibrium();
	void Run();
	void RunNeighbor33FinalLocalSearch();
	void Run2();
	void Run1();
	void InitProfit();
	void InitFitness();
	int  Dominance(std::vector<double>   obj1Vec, std::vector<double>   obj2Vec);
	int  IndividualDominance(std::pair<int, int> speciesId_IndividualId_1, std::pair<int, int> speciesId_IndividualId_2);
	std::vector<std::vector<NonDominatedSortElement>> CoGA::FrontSorting(std::vector<int> speciesIdVec, std::vector<int> individualVec);
	std::vector<double> CalculateProfit(int peciesId, int individualId);
	std::vector<double> CalculateProfit( Individual individual);
	
	std::vector<int> PartnerSelection(int individualId);
	void UpdateProfitPPF(int speciesId, int individualId);
	void UpdateProfitPPR(int speciesId, int individualId);
	void UpdateProfitPA(int speciesId, int individualId);
	void UpdateProfitPB(int speciesId, int individualId);
	void UpdateProfit(int speciecs_index, int individualId);

	int Negotiation();// return Species id
	int Negotiation(std::vector<std::vector<Individual>> individualVec);
	std::vector<std::vector<int>>  FullCombination6(int M);
	std::vector<std::vector<int>>  FullCombination5(int M);
	std::vector<std::vector<int>>  FullCombination4(int M);	
	std::vector<std::vector<int>>  FullCombination3(int M);
	std::vector<std::vector<int>>  FullCombination2(int M);
	std::vector<std::pair<int,int>> IdenticalChoromosomeAmongSpecies();
	void FindBestSolution();
	void FindBestSolution2();
	void FindBestSolution(std::vector<std::vector<Individual>> individualVec);
	void InterativeLocalSearch();
	void InterativeLocalSearch(int speciesId, int individualId);
	void InterativeLocalSearch(int speciesId, Individual& individual);
	bool LocalSearch(int terimalId, int individualId,std::vector<double>& priceVec);
	bool LocalSearch(int terimalId, Individual& individual, std::vector<double>& priceVec);
	bool LocalSearch1(int terimalId, Individual& individual, std::vector<double>& priceVec);
	bool TerminationDeviation();
	void InterativeLocalSearch(int individualId);
	void PrintChromosome();
	void PrintFitness();
	void PrintSolution(int peciesId, int individualId);
	void PrintSolution(Individual individual);
	void PrintSolution(Individual *pindividual);
	void SaveBestSolution(std::string fileName);
	void SaveFitness(std::string fileName);
	void SaveProfit(std::string fileName);
	
	void PrintVersion();
	void SaveVersion(std::ostream &ofs);
	std::vector<std::vector<double>> BackUpProfit();
	void SetProfit(std::vector<std::vector<double>> &profitVec);
	std::vector<std::vector<double>> BackUpFitness();
	void SetFitness(std::vector<std::vector<double>>&fitnessVec);
	std::vector<std::vector<double>>  GetProfitMatchingAll(int speciesId);

	std::vector<std::vector<std::vector<double>>> BackUpChromosome();
	void SetChromosome(std::vector<std::vector<std::vector<double>>> &);
	void SaveContourmap(int iteration,int speciesId);
	void SaveContourmap(std::string name,const std::vector<std::vector<double>>& contourMat);
	void SaveSearchRecordOfBestIndividual(std::string name);
	void SaveFitnessRecord(std::string name);
	void SaveDominateBenchmarkSolution(std::string name);
	void SaveChromosome(std::string name);
	void SaveChromosomePrice(std::string name);
	void SaveChromosomePrice(std::string fileName, std::vector<std::vector<Individual>> individualMat);
	void SaveNeighborLevel(std::string name);
	void SaveAlgorithmParameters(std::string name);
	void SaveAlgorithmParameters(std::ofstream &ofs);
	void UpdateFitnessRecord();
	std::vector<Species*> _SpeciesVec;
	std::vector<Terminal> _TerminalVec;
	CoGAParameter* _pCoGAParameter;
	BenchmarkSolution _BenchmarkSolution;
	//std::pair<int, int> _BestSoltion;
	Individual _BestSoltion;
	LSParameters _LSParameters;
	std::map<std::pair<int, int>, std::vector<double>> _LocalSearchImprovement; // % of profit 
	ToroidalGrid _ToroidalGrid;
	SBP _SBP;
	double _CalculatationTime;
	double _CoGAcalculatationTime;
	double _LocalSearchTime;
};


#endif