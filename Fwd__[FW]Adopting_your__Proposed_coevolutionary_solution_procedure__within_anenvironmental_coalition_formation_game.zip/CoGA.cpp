#include "CoGA.h"
#include "ExceptionHelper.h"
#include "ArrayHelper.h"
#include"Random.h"
#include "ToroidalGrid.h"
#include "TimeHelpers.h"
#include "Permutation.h"
#include <map>
#include <numeric>
#include <omp.h>
//----------------------------------Individual--------------------------------------//
Individual::Individual()
{
	_Fitness = std::numeric_limits<double>::max();
	_Profit = std::numeric_limits<double>::min();
	_NeighborLevel = 1;	
	_BestPartnerCount =0;
	_FitnessShareing = 0;
}
Individual::Individual(int index)
{
	_Fitness = std::numeric_limits<double>::max();
	_Profit = std::numeric_limits<double>::min();
	_Index = index;
	_NeighborLevel = 1;
	_BestPartnerCount = 0;
	_FitnessShareing = 0;
}
Individual::Individual(Individual *indivdual)
{
	_Chromosome = indivdual->_Chromosome;
	_Fitness = indivdual->_Fitness;
	_Profit = indivdual->_Profit;
	_ProfitVec = indivdual->_ProfitVec;
	_Index = indivdual->_Index;
	_NeighborLevel = indivdual->_NeighborLevel;
	_BestPartnerCount = indivdual->_BestPartnerCount;
	_FitnessShareing = indivdual->_FitnessShareing;
}
std::vector<double> Individual::Decode(double lowerBound, double upperBound)
{
	std::vector<double> value;
	for (int i = 0; i < _Chromosome.size(); i++)
	{
		value.push_back(DECODE(_Chromosome[i], lowerBound, upperBound));
	}
	return value;
}
void Individual::PrintChromosome()
{
	for (int i = 0; i < _Chromosome.size();i++)
	{
		std::cout << _Chromosome[i] << "\t";
	}
	std::cout << std::endl;
}
void Individual::PrintFitness()
{
	std::cout << _Fitness;
}

void Individual::Copy(Individual individual)
{
	_Chromosome= individual._Chromosome;
	_Fitness = individual._Fitness;
	_Profit = individual._Profit;
	_Index = individual._Index;
}

void  Individual::SetChromosome(std::vector<double> chromosomeVec)
{
	if (_Chromosome.size() == chromosomeVec.size())
	{
		_Chromosome = chromosomeVec;
	}
	
}
void  Individual::SetChromosome(std::vector<double> chromosomeVec, double lowerBound, double upperBound)
{
	if (_Chromosome.size() == chromosomeVec.size())
	{
		for (int i = 0; i < chromosomeVec.size();i++)
		{
			_Chromosome[i] = ENCODE(chromosomeVec[i], lowerBound, upperBound);
		}
	}
}
//------------------------------------------------------------------------//
Species::Species(CoGAParameter* pParameter)
{
	_pCoGAParameter = pParameter;
	_BestIndividual = NULL;
	for (int i = 0; i < _Populations.size(); i++)
	{
		SAFEDELETEPTR(_Populations[i]);
	}
}
Species::Species(CoGAParameter* pParameter, int terminalIndex, CoGA * PCoGA)
{
	_pCoGAParameter = pParameter;
	_TerminalIndex = terminalIndex;
	_PCoGA = PCoGA;
	_BestIndividual = NULL;
	InitPopulations();
}
void Species::InitPopulations()
{
	RandomDouble randmValue(0, 1.0);
	for (int i = 0; i < _pCoGAParameter->_PopulationNum; i++)
	{
		Individual *pIndividual =new Individual(_Populations.size());
		randmValue.GetArray(pIndividual->_Chromosome, _pCoGAParameter->_GeneNum);
#ifdef INTERGR_PRICE
		for (int p = 0; p < pIndividual->_Chromosome.size();p++)
		{
			pIndividual->_Chromosome[p] = RoundDouble(pIndividual->_Chromosome[p]);
		}
#endif
		_Populations.push_back(pIndividual);
	}
}

 
void Species::CalculateProfit(int index)
{
		
	std::vector<double> vec = _Populations[index]->Decode(_pCoGAParameter->_PriceLowerBound,_pCoGAParameter->_PriceUpperBound);
	for (int i = 0; i < vec.size(); i++)
	{
		_PCoGA->_TerminalVec[i]._p = vec[i];
	}
	NewtonRaphsonMethod(_PCoGA->_TerminalVec, _PortPara);
	_Populations[index]->_ProfitVec = Profit(_PCoGA->_TerminalVec, _PortPara);
	_Populations[index]->_Profit = _Populations[index]->_ProfitVec[_TerminalIndex];
	//std::cout << _Populations[index]->_Profit << std::endl;
}
std::vector<double> Species::CalculateProfitVec(int index)
{
	std::vector<double> vec = _Populations[index]->Decode(_pCoGAParameter->_PriceLowerBound, _pCoGAParameter->_PriceUpperBound);
	for (int i = 0; i < vec.size(); i++)
	{
		_PCoGA->_TerminalVec[i]._p = vec[i];
	}
	NewtonRaphsonMethod(_PCoGA->_TerminalVec, _PortPara);
	return Profit(_PCoGA->_TerminalVec,_PortPara);
}
void  Species::PrintChromosome()
{
	for (int i = 0; i < _Populations.size(); i++)
	{
		std::cout << "individual " << i << "\t"; 
		_Populations[i]->PrintChromosome();
	}	
}
void Species::PrintFitness()
{
	for (int i = 0; i < _Populations.size(); i++)
	{
		 
		_Populations[i]->PrintFitness();
		std::cout << "\t";
	}
}
void   Species::InitFitness()
{
	ToroidalGrid toroidalGrid(_Populations.size());
	 
	for (int i = 0; i < _Populations.size(); i++)
	{
		UpdateFitness(i);
		/*std::vector<int> vec = toroidalGrid.Neighborhood_3_3(i);
		double minProfit = std::numeric_limits<double>::max();
		double maxProfit = std::numeric_limits<double>::min();

		double tempValue;
		for (int j = 0; j < vec.size();j++)
		{
			tempValue = _Populations[vec[j]]->_Profit;
			if (tempValue > maxProfit)
				maxProfit = tempValue;
			if (tempValue < minProfit)
				minProfit = tempValue;
		}
		if (EQUAL_ZERO(maxProfit - minProfit))
		{
			_Populations[i]->_Fitness = 0;
		}else
		_Populations[i]->_Fitness = (maxProfit - _Populations[i]->_Profit) / (maxProfit-minProfit);*/
	}
}

std::vector<Individual>   Species::GetIndividuals(std::vector<int> individualIdVec)
{
	std::vector<Individual> vec;
	for (int i = 0; i < individualIdVec.size(); i++)	
		vec.push_back(*_Populations[individualIdVec[i]]);
	return vec;
	
}
std::pair<int, int> Species::UpdatePopulation(std::pair<Individual, Individual>offsprings, std::vector<int>  neighborhood, bool &improvementFlag)
{
	improvementFlag = false;
	if (neighborhood.size() >= 2)
	{

		std::vector<Individual> vec;
		for (int i = 0; i < neighborhood.size(); i++)
		{
			vec.push_back(*_Populations[neighborhood[i]]);
		}
		ArraySort(vec, true);
		std::pair<int, int> updateInexPair(vec[0]._Index, vec[1]._Index);
		std::pair<double, double> profitVec1(_Populations[updateInexPair.first]->_Profit, _Populations[updateInexPair.second]->_Profit);
		 
		
		_Populations[updateInexPair.first]->Copy(offsprings.first);
		_Populations[updateInexPair.first]->_Index = updateInexPair.first;
		
		_Populations[updateInexPair.second]->Copy(offsprings.second);
		_Populations[updateInexPair.second]->_Index = updateInexPair.second;

		UpdateProfit(updateInexPair.first);
		UpdateProfit(updateInexPair.second);
		std::pair<double, double> profitVec2(_Populations[updateInexPair.first]->_Profit, _Populations[updateInexPair.second]->_Profit);
		if (profitVec2.first> profitVec1.first ||
			profitVec2.second> profitVec1.second)
		{
			improvementFlag = true;
		}

		return updateInexPair;
	}
}
void Species::UpdateProfit(int individualIndex, int geneId,Individual partnterIndividual)
{
	
	_Populations[individualIndex]->_Chromosome[geneId] = partnterIndividual._Chromosome[geneId];
	CalculateProfit(individualIndex);
	if (_Populations[individualIndex]->_Profit > _BestIndividual->_Profit)
	{
		_BestIndividual = _Populations[individualIndex];
		_BestIndividualRecord.push_back(Individual(_BestIndividual));
	}
	
}
void Species::UpdateProfit(int individualIndex)
{
	CalculateProfit(individualIndex);
}
void Species::InitFitness(int individualIndex)
{
#ifdef FITNESSSHARING
	{

		std::vector<std::vector<double>> profitVec;

		ToroidalGrid toroidalGrid(_pCoGAParameter->_PopulationNum);
		//std::vector<int>  neighborhood = toroidalGrid.NeighborhoodLevel(toroidalGrid._MaxLevel, individualIndex);
		std::vector<int>  neighborhood = toroidalGrid.Neighborhood_3_3(individualIndex);
		std::vector<double>maxProfitVec(_PCoGA->_SpeciesVec.size(), std::numeric_limits<double>::min());
		std::vector<double>minProfitVec(_PCoGA->_SpeciesVec.size(), std::numeric_limits<double>::max());

		for (int j = 0; j < neighborhood.size(); j++)
		{
			int id = 0;
			for (int specciesId = 0; specciesId < _PCoGA->_TerminalVec.size(); specciesId++)
			{
				if (_PCoGA->_SpeciesVec[specciesId] != this)
				{
					_PCoGA->_SpeciesVec[specciesId]->_Populations[neighborhood[j]]->_Chromosome[specciesId] =
						_PCoGA->_SpeciesVec[specciesId]->_Populations[neighborhood[j]]->_Chromosome[specciesId];
				}
				else id = specciesId;

			}
			//CalculateProfit(individualIndex);

			std::vector<double> tempVec = CalculateProfitVec(individualIndex);
			profitVec.push_back(tempVec);
			for (int m = 0; m < tempVec.size(); m++)
			{
				if (tempVec[m]> maxProfitVec[m])
					maxProfitVec[m] = tempVec[m];
				if (tempVec[m] < minProfitVec[m])
					minProfitVec[m] = tempVec[m];
			}
			//sumProfitValue += _Populations[individualIndex]->_Profit;
		}
		std::vector<double> gaps;
		for (int m = 0; m < maxProfitVec.size(); m++)
		{
			gaps.push_back(maxProfitVec[m] - minProfitVec[m]);
		}
		double maxfitness = std::numeric_limits<double>::min();
		//double maxFitnessId = 0;
		for (int i = 0; i < profitVec.size(); i++)
		{
			double tempValue = 0;
			for (int m = 0; m < profitVec[i].size(); m++)
			{
				if (EQUAL_ZERO(gaps[m]))
				{
					tempValue += 1;
				}
				else {
					if (_PCoGA->_SpeciesVec[m] != this)
					{
						tempValue += 0.33333*(profitVec[i][m]-minProfitVec[m]) / gaps[m];
					}
					else tempValue += (profitVec[i][m] - minProfitVec[m]) / gaps[m];

				}
			}
			if (tempValue > maxfitness)
			{
				maxfitness = tempValue;
				//maxFitnessId = i;
			}
		}



		//_Populations[individualIndex]->_FitnessShareing = sumProfitValue;
		_Populations[individualIndex]->_Fitness = maxfitness;

		return;
	}
#endif

	ToroidalGrid toroidalGrid(_pCoGAParameter->_PopulationNum);
	std::vector<int>  neighborhood = toroidalGrid.Neighborhood_3_3(individualIndex);
	//std::vector<int>  neighborhood = toroidalGrid.NeighborhoodLevel(toroidalGrid._MaxLevel,individualIndex);
	double minProfit = std::numeric_limits<double>::max();
	double maxProfit = std::numeric_limits<double>::min();

	double tempValue;
	for (int j = 0; j < neighborhood.size(); j++)
	{
		tempValue = _Populations[neighborhood[j]]->_Profit;
		if (tempValue > maxProfit)
			maxProfit = tempValue;
		if (tempValue < minProfit)
			minProfit = tempValue;
	}
	if (EQUAL_ZERO(maxProfit - minProfit))
	{
		_Populations[individualIndex]->_Fitness = 1;
	}
	else
		_Populations[individualIndex]->_Fitness = (_Populations[individualIndex]->_Profit - minProfit) / (maxProfit - minProfit);

}
double Species::CalculateFitness(int individualIndex)
{

	ToroidalGrid toroidalGrid(_pCoGAParameter->_PopulationNum);
	std::vector<int>  neighborhood = toroidalGrid.Neighborhood_3_3(individualIndex);


	std::vector<double>maxProfitVec(_PCoGA->_SpeciesVec.size(), std::numeric_limits<double>::min());
	std::vector<double>minProfitVec(_PCoGA->_SpeciesVec.size(), std::numeric_limits<double>::max());

	for (int j = 0; j < neighborhood.size(); j++)
	{
		int id = 0;
		for (int m = 0; m <_Populations[individualIndex]->_ProfitVec.size(); m++)
		{
			if (_Populations[neighborhood[j]]->_ProfitVec[m]> maxProfitVec[m])
				maxProfitVec[m] = _Populations[neighborhood[j]]->_ProfitVec[m];
			if (_Populations[neighborhood[j]]->_ProfitVec[m] < minProfitVec[m])
				minProfitVec[m] = _Populations[neighborhood[j]]->_ProfitVec[m];
		}
		//sumProfitValue += _Populations[individualIndex]->_Profit;
	}
	std::vector<double> gaps;
	for (int m = 0; m < maxProfitVec.size(); m++)
	{
		gaps.push_back(maxProfitVec[m] - minProfitVec[m]);
	}
	double maxfitness = std::numeric_limits<double>::min();
	//double maxFitnessId = 0;

	double tempValue = 0;
	for (int m = 0; m < _Populations[individualIndex]->_ProfitVec.size(); m++)
	{
		if (EQUAL_ZERO(gaps[m]))
		{
			tempValue += 1;
		}
		else {
			if (_PCoGA->_SpeciesVec[m] != this)
			{
				tempValue += _pCoGAParameter->_FitnessWeight*(_Populations[individualIndex]->_ProfitVec[m] - minProfitVec[m]) / gaps[m];
			}
			else tempValue += (_Populations[individualIndex]->_ProfitVec[m] - minProfitVec[m]) / gaps[m];

		}
	}
	if (tempValue > maxfitness)
	{
		maxfitness = tempValue;
		//maxFitnessId = i;
	}




	//_Populations[individualIndex]->_FitnessShareing = sumProfitValue;
	return maxfitness;
}
void Species::UpdateFitness(int individualIndex)
{
#ifdef FITNESSSHARING
	{
		
		
		
		ToroidalGrid toroidalGrid(_pCoGAParameter->_PopulationNum);
		std::vector<int>  neighborhood = toroidalGrid.Neighborhood_3_3(individualIndex);
				

		std::vector<double>maxProfitVec(_PCoGA->_SpeciesVec.size(), std::numeric_limits<double>::min());
		std::vector<double>minProfitVec(_PCoGA->_SpeciesVec.size(), std::numeric_limits<double>::max());

		for (int j = 0; j < neighborhood.size(); j++)
		{
			int id = 0;			 			 			
			for (int m = 0; m <_Populations[individualIndex]->_ProfitVec.size(); m++)
			{
				if (_Populations[neighborhood[j]]->_ProfitVec[m]> maxProfitVec[m])
					maxProfitVec[m] = _Populations[neighborhood[j]]->_ProfitVec[m];
				if (_Populations[neighborhood[j]]->_ProfitVec[m]< minProfitVec[m])
					minProfitVec[m] = _Populations[neighborhood[j]]->_ProfitVec[m];
			}
			//sumProfitValue += _Populations[individualIndex]->_Profit;
		}
		std::vector<double> gaps;
		for (int m = 0; m < maxProfitVec.size(); m++)
		{
			gaps.push_back(maxProfitVec[m] - minProfitVec[m]);
		}
		double maxfitness=std::numeric_limits<double>::min();
		//double maxFitnessId = 0;
		 
			double tempValue = 0;
			for (int m = 0; m< _Populations[individualIndex]->_ProfitVec.size(); m++)
			{
				if (EQUAL_ZERO(gaps[m]))
				{
					tempValue += 1;
				}
				else {
					if (_PCoGA->_SpeciesVec[m] != this)
					{
						tempValue += _pCoGAParameter->_FitnessWeight*(_Populations[individualIndex]->_ProfitVec[m] - minProfitVec[m]) / gaps[m];
					}
					else tempValue += (_Populations[individualIndex]->_ProfitVec[m] - minProfitVec[m]) / gaps[m];
					
				}				
			}
			if (tempValue > maxfitness)
			{
				maxfitness = tempValue;
				//maxFitnessId = i;
			}			
		 



		//_Populations[individualIndex]->_FitnessShareing = sumProfitValue;
		_Populations[individualIndex]->_Fitness = maxfitness;

		return;
	}
#endif

	ToroidalGrid toroidalGrid(_pCoGAParameter->_PopulationNum);
	std::vector<int>  neighborhood = toroidalGrid.Neighborhood_3_3(individualIndex);
	//std::vector<int>  neighborhood = toroidalGrid.NeighborhoodLevel(toroidalGrid._MaxLevel,individualIndex);
	double minProfit = std::numeric_limits<double>::max();
	double maxProfit = std::numeric_limits<double>::min();

	double tempValue;
	for (int j = 0; j < neighborhood.size(); j++)
	{
		tempValue = _Populations[neighborhood[j]]->_Profit;
		if (tempValue > maxProfit)
			maxProfit = tempValue;
		if (tempValue < minProfit)
			minProfit = tempValue;
	}
	if (EQUAL_ZERO(maxProfit - minProfit))
	{
		_Populations[individualIndex]->_Fitness = 1;
	}
	else
		_Populations[individualIndex]->_Fitness = ( _Populations[individualIndex]->_Profit - minProfit) / (maxProfit - minProfit);
}
double Species::ChromosomeDeviation()
{
	double meanValue = 0;
	int size = _Populations.size();
	for (int m = 0; m < size; m++)
	{
		meanValue += _Populations[m]->_Chromosome[_TerminalIndex];
	}
	meanValue = meanValue / (1.0* _Populations.size());
	double deviation = 0;
	for (int m = 0; m < size; m++)
	{
		deviation += (_Populations[m]->_Chromosome[_TerminalIndex] - meanValue)*(_Populations[m]->_Chromosome[_TerminalIndex] - meanValue) / (1.0*size);
	}
	return deviation;
}
std::pair<double, double> Species::FitnessMeanDeviation()
{
	double mean = 0, dev=0;
	for (int i = 0; i < _Populations.size(); i++)
	{
		mean += _Populations[i]->_Fitness;
	}
	mean = mean / (_Populations.size()*1.0);
	for (int i = 0; i < _Populations.size(); i++)
	{
		dev += (_Populations[i]->_Fitness - mean)*(_Populations[i]->_Fitness- mean);
	}
	dev =std::sqrt( dev / ((_Populations.size()-1)*1.0));
	//dev = dev / ((_Populations.size() - 1)*1.0);
	return std::pair<double, double>(mean,dev);
}
void Species::UpdateFitnessSumList()
{
	_FitnessMeanDeviastionList.push_back(FitnessMeanDeviation());
}

int  Species::WorseIndividualId()
{
	int id = 0;
	double minFitness = std::numeric_limits<double>::max();
	for (int i = 0; i < _Populations.size();i++)
	{
		if (_Populations[i]->_Fitness < minFitness)
		{
			minFitness = _Populations[i]->_Fitness;
			id = i;
		}
	}
	return id;
}
int  Species::BestIndividualId()
{
	int id = 0;
	double maxFitness = std::numeric_limits<double>::min();
	for (int i = 0; i < _Populations.size(); i++)
	{
		if (_Populations[i]->_Fitness > maxFitness)
		{
			maxFitness = _Populations[i]->_Fitness;
			id = i;
		}
	}
	return id;
}
//------------------------------------------------------------------------//
PriceAndProfit::PriceAndProfit()
{
	_SpeciesId = 0;
	_IndividualId = 0;
	_Profit = 0;
}
PriceAndProfit::PriceAndProfit(PriceAndProfit * priceAndProfit)
{
	_SpeciesId = priceAndProfit->_SpeciesId;
	_IndividualId = priceAndProfit->_IndividualId;
	_ProfitVec = priceAndProfit->_ProfitVec;
	_Profit = priceAndProfit->_Profit;
}
PriceAndProfit::PriceAndProfit(int speciesid, int indId, double profit)
{
	_SpeciesId = speciesid;
	_IndividualId = indId;
	_Profit = profit;

}
PriceAndProfit::PriceAndProfit(int speciesid, int indId, double profit, std::vector<double> profitVec)
{
	_SpeciesId = speciesid;
	_IndividualId = indId;
	_ProfitVec = profitVec;
	_Profit = profit;
}
 
//------------------------------------------------------------------------//
SBP::SBP()
{
	 
}
SBP::SBP(CoGAParameter* pcoGapara)
{
	 
	_pCoGAParameter = pcoGapara;
}

 
 
 
bool SBP::AcceptPoolChecking(int speciesId, int individualId)
{
	bool flag = true;
	std::vector<bool> flagVec(_SolutionPool.size(),false);
	flagVec[speciesId] = true;
	if (_AcceptPool.size())
	for (int j = 0; j < _AcceptPool.size(); j++)
	{
		if (j != speciesId)
		{
			for (int i = 0; i < _AcceptPool[j].size();i++)
			{
				

					
				if (1==ArrayDominate(_AcceptPool[j][i]._ProfitVec, _SolutionPool[speciesId][individualId]._ProfitVec))
				{
					flagVec[j] = true;
					break;
				}
				if (ArrayEqual(_AcceptPool[j][i]._ProfitVec, _SolutionPool[speciesId][individualId]._ProfitVec))
				{
					flagVec[j] = true;
					break;
				}
			}
		}	
	}
	for (int i = 0; i < flagVec.size();i++)
	{
		flag = flag & flagVec[i];
	}
	return flag;
}
bool SBP::Negotiation()//version 2 without using parameters
{
	int length = _SolutionPool[0].size();
	 
	for (int i = 0; i < length; i++)
	{
		std::cout << "Negotiation " << i << std::endl;
		if (i==0)
		{
			
			for (int j = 0; j < _SolutionPool.size(); j++)
			{
				std::vector<PriceAndProfit> vecTemp;
				vecTemp.push_back(_SolutionPool[j][i]);
				_AcceptPool.push_back(vecTemp);
			}

		}
		else
		{
			std::vector<PriceAndProfit> vecTemp;
			for (int j = 0; j < _SolutionPool.size(); j++)
				_AcceptPool[j].push_back(_SolutionPool[j][i]);			
		}
		
		
		bool flag = false;
		for (int j = 0; j < _SolutionPool.size(); j++)
		{
			
			if (AcceptPoolChecking(j, i))
			 {

				_SpeciesIndividualId.first = _SolutionPool[j][i]._SpeciesId;
				_SpeciesIndividualId.second=_SolutionPool[j][i]._IndividualId;
				return true;
			}  
			
			
		}		
		
		


	}
}
 
 
void  SBP::InitSolutionPool(std::vector<Species*> &speciesVec)
{
	
	for (int i = 0; i < speciesVec.size(); i++)
	{
		
		std::vector<PriceAndProfit> vecTemp;
		for (int j = 0; j < speciesVec[i]->_Populations.size(); j++)
		{			
			vecTemp.push_back(PriceAndProfit(i, j, speciesVec[i]->_Populations[j]->_Profit, speciesVec[i]->_Populations[j]->_ProfitVec));
		}
		ArraySort(vecTemp,false); 
		_SolutionPool.push_back(vecTemp);
	}
	
}
void  SBP::InitSolutionPool(std::vector<std::vector<Individual>> &speciesVec)
{
	for (int i = 0; i < speciesVec.size(); i++)
	{

		std::vector<PriceAndProfit> vecTemp;
		for (int j = 0; j < speciesVec[i].size(); j++)
		{			
			vecTemp.push_back(PriceAndProfit( i,j, speciesVec[i][j]._ProfitVec[i], speciesVec[i][j]._ProfitVec));
		}
		ArraySort(vecTemp, false);
		_SolutionPool.push_back(vecTemp);
	}	
}
//------------------------------------------------------------------------//
CoGA::CoGA()
{
	_pCoGAParameter = NULL;
	_CoGAcalculatationTime = .0;
	_LocalSearchTime = .0;
	_CalculatationTime = .0;
}
CoGA::~CoGA()
{
	SAFEDELETEPTR(_pCoGAParameter);
	for (int i = 0; i < _SpeciesVec.size();i++)
	{
		SAFEDELETEPTR(_SpeciesVec[i]);
	}
	
}
void CoGA::InitCoGAParameter()
{
	_pCoGAParameter = new CoGAParameter();
	_ToroidalGrid.SetParameter(_pCoGAParameter->_PopulationNum);
}
void CoGA::InitCoGAParameter(CoGAParameter* pCoGAParameter)
{
	_pCoGAParameter = pCoGAParameter;
}
void CoGA::InitTerminals(std::vector<Terminal> terminals)
{
	_TerminalVec = terminals;
}

void CoGA::InitSpecies()
{
	for (int i = 0; i < _TerminalVec.size(); i++)
	{
		Species *pSp = new Species(_pCoGAParameter, i, this);
		
		_SpeciesVec.push_back(pSp);
	}	
}
std::pair<int, int> CoGA::PartensSelection(  std::vector<Individual>  candidateIndividuals)
{
	switch (_pCoGAParameter->_ParentSelectionPara)
	{
		 
			
	case _RouletteWheel:
		return RouletteWheel(candidateIndividuals);
		break;
	case _Tournament:
		break;
	case _Rank:
		return PSRankMethod(candidateIndividuals);
		break;
	case _Elitism:
		break;
	case _Random:
		break;		
	case _StochasticUniversalSampling:
		break; 			
	default:
		break;
	}
}

int CoGA::RouletteSelect(std::vector<double> weight)
{
	// calculate the total weight
	double weight_sum = ArraySum(weight);
	
	RandomDouble randDouble(0.0, 1.0);
	double pro = randDouble.GetDouble();	
	double value = pro*weight_sum;	
	for (int i = 0; i < weight.size(); i++)
	{
		value -= weight[i];
		if (value < 0)
			return i;
	}
	// when rounding errors occur, we return the first item's index 
	return 0;
}
std::pair<int, int> CoGA::RouletteWheel(std::vector<Individual> candidateIndividuals)
{
	if (candidateIndividuals.size() < 2)
		PRINTERRORFILELINE();
	std::vector<double> weight;
	for (int i = 0; i < candidateIndividuals.size();i++)
	{
		weight.push_back(candidateIndividuals[i]._Fitness);
	}
	std::pair<int, int> idPair;
	idPair.first = RouletteSelect(weight);
	idPair.second = RouletteSelect(weight);
	/*while (idPair.first == idPair.second)
	{
		idPair.second = RouletteSelect(weight);
	}*/
	return std::pair<int, int>(candidateIndividuals[idPair.first]._Index, candidateIndividuals[idPair.second]._Index);;
}
std::pair<int, int> CoGA::PSRankMethod(  std::vector<Individual>  candidateIndividuals)
{
	if (candidateIndividuals.size() < 2)
		PRINTERRORFILELINE();
	ArraySort(candidateIndividuals, _pCoGAParameter->_MinOrMaxProblem);
	return std::pair<int, int>(candidateIndividuals[0]._Index, candidateIndividuals[1]._Index);
}
std::pair<Individual, Individual> CoGA::CrossOver(Individual father, Individual mother, int geneIdex)
{
	
		switch (_pCoGAParameter->_CrossOverPara)
		{
		case CrossOverPara::_MultiPoint:
			;
			break;
		case CrossOverPara::_OnePoint:
			return CrossOverOnePoint(father, mother, geneIdex);
			break;
		case CrossOverPara::_Uniform:
			;
			break;
		case CrossOverPara::_WholeArithmeticRecombination:
			;
			break;
		default:
			break;
		}
	 
}

std::pair<Individual, Individual> CoGA::CrossOverOnePoint(Individual father, Individual mother, int geneIdex)
{
	RandomInt randInt(0, _pCoGAParameter->_GeneNum-1);
	Individual son(&father);
	Individual daughter(&mother);
	RandomDouble pro(0, 1.0);
	if (pro.GetDouble() < _pCoGAParameter->_ProCrossover)
	{
		double beta = pro.GetDouble();		
		son._Chromosome[geneIdex] = (1 - beta)* mother._Chromosome[geneIdex] +beta* father._Chromosome[geneIdex];
		daughter._Chromosome[geneIdex]  = (1 - beta)* father._Chromosome[geneIdex] + beta* mother._Chromosome[geneIdex];	

#ifdef INTERGR_PRICE
		 
		son._Chromosome[geneIdex] = RoundDouble(son._Chromosome[geneIdex]);
		daughter._Chromosome[geneIdex] = RoundDouble(daughter._Chromosome[geneIdex]);
#endif
		if (son._Chromosome[geneIdex]>1)
		{
			son._Chromosome[geneIdex] = 1;
		}
		if	(daughter._Chromosome[geneIdex]>1)
		{
			daughter._Chromosome[geneIdex] = 1;
		}
		if (son._Chromosome[geneIdex] < 0)
		{
			son._Chromosome[geneIdex] = 0;
		}
		if (daughter._Chromosome[geneIdex] < 0)
		{
			daughter._Chromosome[geneIdex] = 0;
		}
	}
	return std::pair<Individual, Individual>(son, daughter);
}
void CoGA::Mutation(int speciesId, int individualIdex)
{
	RandomDouble pro(0, 1.0);
	if (pro.GetDouble() < _pCoGAParameter->_ProMutation)
	{

		switch (_pCoGAParameter->_MutationPara)
		{
		case MutationPara::_BitFlip:
			break;
		case MutationPara::_Inversion:
			break;
		case MutationPara::_RandomResetting:
			MutationRandomResetting(speciesId, individualIdex);
			break;
		case MutationPara::_Scramble:
			break;
		case MutationPara::_Swap:
			break;
		default:
			break;
		}
	}
}
void CoGA::MutationRandomResetting(int speciesId, int individualIdex)
{
	RandomDouble randDouble(0, 1);
	_SpeciesVec[speciesId]->_Populations[individualIdex]->_Chromosome[speciesId] = randDouble.GetDouble();

#ifdef INTERGR_PRICE
	_SpeciesVec[speciesId]->_Populations[individualIdex]->_Chromosome[speciesId] =
	RoundDouble(_SpeciesVec[speciesId]->_Populations[individualIdex]->_Chromosome[speciesId]);
#endif

}

void CoGA::Mutation(Individual & individual, int geneIdex)
{
	RandomDouble pro(0, 1.0);
	if (pro.GetDouble() < _pCoGAParameter->_ProMutation)
	{

		switch (_pCoGAParameter->_MutationPara)
		{
		case MutationPara::_BitFlip:
			break;
		case MutationPara::_Inversion:
			break;
		case MutationPara::_RandomResetting:
			MutationRandomResetting(individual,  geneIdex);
			break;
		case MutationPara::_Scramble:
			break;
		case MutationPara::_Swap:
			break;
		default:
			break;
		}
	}
}
void CoGA::MutationRandomResetting(Individual & individual, int geneIdex)
{
	 
	RandomDouble randDouble(0, 1);
	individual._Chromosome[geneIdex] = randDouble.GetDouble();
#ifdef INTERGR_PRICE
	individual._Chromosome[geneIdex] =
		RoundDouble(individual._Chromosome[geneIdex]);
#endif
}
std::pair<int, int> CoGA::UpdatePopulation(int speciesId, std::pair<Individual, Individual>offsprings, std::vector<int>  neighborhood)
{
	if (neighborhood.size() >= 2)
	{

		std::vector<Individual> vec;
		for (int i = 0; i < neighborhood.size(); i++)
		{
			vec.push_back(*_SpeciesVec[speciesId]->_Populations[neighborhood[i]]);
		}
		ArraySort(vec, true);
		std::pair<int, int> updateInexPair(vec[0]._Index, vec[1]._Index);

		std::vector<double> profitVec0 = CalculateProfit(speciesId, vec[0]._Index);
		std::vector<double> profitVec1 = CalculateProfit(speciesId, vec[1]._Index);

		std::vector<double> profitoffspringVec0 = CalculateProfit(offsprings.first);
		std::vector<double> profitoffspringVec1 = CalculateProfit(offsprings.second);
		if (profitoffspringVec0[speciesId]> profitVec0[speciesId])
		{
			_SpeciesVec[speciesId]->_Populations[updateInexPair.first]->Copy(offsprings.first);
			_SpeciesVec[speciesId]->_Populations[updateInexPair.first]->_Index = updateInexPair.first;
		}
		
		if (profitoffspringVec1[speciesId] > profitVec1[speciesId])
		{
			_SpeciesVec[speciesId]->_Populations[updateInexPair.second]->Copy(offsprings.second);
			_SpeciesVec[speciesId]->_Populations[updateInexPair.second]->_Index = updateInexPair.second;
		}

		
		return updateInexPair;
	}
}
void  CoGA::RunNeighbor33FinalLocalSearch()
{
	TimeHelpers::Timer time;
	time.Start();
	_ToroidalGrid.SetParameter(_pCoGAParameter->_PopulationNum);
	InitProfit();
	std::cout << "initialize profit done \n";
	//InterativeLocalSearch();

	InitFitness();

	UpdateFitnessRecord();
	std::cout << "initialize fitness done \n";
	RandomInt randomIntSpecies(0, _TerminalVec.size() - 1);
	RandomInt randomIntIndividual(0, _pCoGAParameter->_PopulationNum - 1);
	int iteration = 0;
	//SaveContourmap(iteration+1, 0);

	while (iteration < _pCoGAParameter->_MaxIteration)
	{
		int speciecs_index = randomIntSpecies.GetInt();
		//int individualId = _SpeciesVec[speciecs_index]->WorseIndividualId();
		//int individualId = _SpeciesVec[speciecs_index]->BestIndividualId();
		int individualId = randomIntIndividual.GetInt();

		std::vector<int>  neighborhood = _ToroidalGrid.Neighborhood_3_3(individualId);
		std::vector<Individual> evolingNeighborhood = _SpeciesVec[speciecs_index]->GetIndividuals(neighborhood);


		std::pair<int, int> parentsId = PartensSelection(evolingNeighborhood);
		Individual father(_SpeciesVec[speciecs_index]->_Populations[parentsId.first]);
		Individual mother(_SpeciesVec[speciecs_index]->_Populations[parentsId.second]);
		std::pair<Individual, Individual>offsprings = CrossOver(father, mother, speciecs_index);
		Mutation(offsprings.first, speciecs_index);
		Mutation(offsprings.second, speciecs_index);

		/*for (int m = 0; m < neighborhood.size(); m++)
		{
		Mutation(speciecs_index, neighborhood[m]);
		}*/

		bool improvementFlag;
		std::pair<int, int> updateInidvidualIndexPair = _SpeciesVec[speciecs_index]->UpdatePopulation(offsprings, neighborhood, improvementFlag);
		 
		 
		//for (int specciesId = 0; specciesId < _TerminalVec.size(); specciesId++)
		//{
		//	if (specciesId != speciecs_index)
		//	{
		//		std::vector<int> tempNeighborhood = _ToroidalGrid.Neighborhood_3_3(individualId);
		//		std::vector<Individual> symbioticghborhood = _SpeciesVec[specciesId]->GetIndividuals(tempNeighborhood);
		//		Individual bestPartner = SelectBestFitness(symbioticghborhood);
		//		//	newChromosome[speciecs_index] = bestPartner._Chromosome[specciesId];
		//		_SpeciesVec[speciecs_index]->_Populations[individualId]->_Chromosome[specciesId] =
		//			bestPartner._Chromosome[specciesId];
		//	}
		//}
		//for offspring
		for (int specciesId = 0; specciesId < _TerminalVec.size(); specciesId++)
		{
			if (specciesId != speciecs_index)
			{
				
				std::vector<int> tempNeighborhood = PartnerSelection( individualId);
				std::vector<Individual> symbioticghborhood = _SpeciesVec[specciesId]->GetIndividuals(tempNeighborhood);
				Individual bestPartner = SelectBestFitness(symbioticghborhood);
				_SpeciesVec[speciecs_index]->_Populations[updateInidvidualIndexPair.first]->_Chromosome[specciesId] =
					bestPartner._Chromosome[specciesId];
				_SpeciesVec[speciecs_index]->_Populations[updateInidvidualIndexPair.second]->_Chromosome[specciesId] =
					bestPartner._Chromosome[specciesId];
			}

		}
		
		for (int specciesId = 0; specciesId < _TerminalVec.size(); specciesId++)
		{
			_SpeciesVec[specciesId]->UpdateProfit(updateInidvidualIndexPair.first);
			_SpeciesVec[specciesId]->UpdateProfit(updateInidvidualIndexPair.second);
		}

		std::vector<int>  neighborhood1 = _ToroidalGrid.Neighborhood_3_3(updateInidvidualIndexPair.first);
		for (int n = 0; n < neighborhood1.size(); n++)
		{
			for (int specciesId = 0; specciesId < _TerminalVec.size(); specciesId++)
			{
				_SpeciesVec[specciesId]->UpdateFitness(neighborhood1[n]);
			}
		}

		std::vector<int>  neighborhood2 = _ToroidalGrid.Neighborhood_3_3(updateInidvidualIndexPair.second);
		for (int n = 0; n < neighborhood2.size(); n++)
		{
			for (int specciesId = 0; specciesId < _TerminalVec.size(); specciesId++)
			{
				_SpeciesVec[specciesId]->UpdateFitness(neighborhood2[n]);
			}
		}
		

		UpdateFitnessRecord();
		
		iteration++;
		std::cout << "main iteration " << iteration << std::endl;
		 
	}
	//SaveContourmap(iteration+1, 0);
	//std::vector<std::vector<std::vector<double>>> chromosomeBakcup = BackUpChromosome();

	InterativeLocalSearch();
	//FindBestSolution();
	FindBestSolution2();

	_CalculatationTime = time.GetTimeInSecond();
	std::cout << "local search for the best solution \n";

}
std::vector<int> CoGA::PartnerSelection(int individualId)
{
	switch (_pCoGAParameter->_ScopeofPartners)
	{
	case ScopeofPartners::_SE:
		
		return _ToroidalGrid.EntireNeighbor();
		break;
	case ScopeofPartners::_SN:

		return _ToroidalGrid.Neighborhood_3_3(individualId);
		break;	
	}
}
void CoGA::Run2()
{	
	 
	TimeHelpers::Timer time;
	time.Start();
	_ToroidalGrid.SetParameter(_pCoGAParameter->_PopulationNum);
	InitProfit();
	std::cout << "initialize profit done \n";
	//InterativeLocalSearch();

	InitFitness();

	UpdateFitnessRecord();
	std::cout << "initialize fitness done \n";
	RandomInt randomIntSpecies(0, _TerminalVec.size() - 1);
	RandomInt randomIntIndividual(0, _pCoGAParameter->_PopulationNum - 1);
	int iteration = 0;
	//SaveContourmap(iteration+1, 0);
	bool  terminationflag = true;
	while (terminationflag)
	{

		if (iteration < _pCoGAParameter->_MaxIteration)
			terminationflag = true;
		else terminationflag = false;
		_CoGAcalculatationTime += time.GetTimeInSecond();
		if (0 == (iteration % 100))
		{
			SaveChromosomePrice("Price_" + std::to_string(iteration) + ".txt");
		}
		time.Start();



		int speciecs_index = randomIntSpecies.GetInt();
		//int individualId = _SpeciesVec[speciecs_index]->WorseIndividualId();
		//int individualId = _SpeciesVec[speciecs_index]->BestIndividualId();
		int individualId = randomIntIndividual.GetInt();

		std::vector<int>  neighborhood = _ToroidalGrid.Neighborhood_3_3(individualId);
		std::vector<Individual> evolingNeighborhood = _SpeciesVec[speciecs_index]->GetIndividuals(neighborhood);


		std::pair<int, int> parentsId = PartensSelection(evolingNeighborhood);
		Individual father(_SpeciesVec[speciecs_index]->_Populations[parentsId.first]);
		Individual mother(_SpeciesVec[speciecs_index]->_Populations[parentsId.second]);
		std::pair<Individual, Individual>offsprings = CrossOver(father, mother, speciecs_index);
		Mutation(offsprings.first, speciecs_index);
		Mutation(offsprings.second, speciecs_index);

		/*for (int m = 0; m < neighborhood.size(); m++)
		{
		Mutation(speciecs_index, neighborhood[m]);
		}*/

		bool improvementFlag;
		std::pair<int, int> updateInidvidualIndexPair = _SpeciesVec[speciecs_index]->UpdatePopulation(offsprings, neighborhood, improvementFlag);



		//for offspring

		UpdateProfit(speciecs_index, individualId);
		UpdateProfit(speciecs_index, updateInidvidualIndexPair.first);
		UpdateProfit(speciecs_index, updateInidvidualIndexPair.second);

		std::vector<int>  neighborhood1 = _ToroidalGrid.Neighborhood_3_3(updateInidvidualIndexPair.first);
		for (int n = 0; n < neighborhood1.size(); n++)
		{
			for (int specciesId = 0; specciesId < _TerminalVec.size(); specciesId++)
			{
				_SpeciesVec[specciesId]->UpdateFitness(neighborhood1[n]);
			}
		}

		std::vector<int>  neighborhood2 = _ToroidalGrid.Neighborhood_3_3(updateInidvidualIndexPair.second);
		for (int n = 0; n < neighborhood2.size(); n++)
		{
			for (int specciesId = 0; specciesId < _TerminalVec.size(); specciesId++)
			{
				_SpeciesVec[specciesId]->UpdateFitness(neighborhood2[n]);
			}
		}


		UpdateFitnessRecord();

		iteration++;
		std::cout << "main iteration " << iteration << std::endl;
		terminationflag = terminationflag && (!TerminationDeviation());
	}
	SaveChromosomePrice("Price_lastInteration" + std::to_string(iteration) + ".txt");
	//SaveContourmap(iteration+1, 0);
	//std::vector<std::vector<std::vector<double>>> chromosomeBakcup = BackUpChromosome();
	time.Start();
	std::vector<std::vector<Individual>> speciesVec;
	for (int s = 0; s < _SpeciesVec.size(); s++)
	{
		std::vector<Individual> tempVec;
		for (int j = 0; j < _SpeciesVec[s]->_Populations.size(); j++)
		{
			tempVec.push_back(*_SpeciesVec[s]->_Populations[j]);
		}

		ArraySort(tempVec, false);
		speciesVec.push_back(tempVec);

	}
	 


	//std::vector<int> eleVec(5, 0);
	//std::iota(eleVec.begin(), eleVec.end(), 0);
	//Permutation<int> permutation(eleVec, 4);
	//std::vector<std::vector<int>> permutationResult = permutation.GetPermutationResult();
	std::vector<std::vector<int>>  permutationResult;
	if (_TerminalVec.size() == 6)
		permutationResult = FullCombination6(_pCoGAParameter->_Zeta);
	if (_TerminalVec.size() == 5)
		permutationResult = FullCombination5(_pCoGAParameter->_Zeta);
	if (_TerminalVec.size() == 4)
		permutationResult = FullCombination4(_pCoGAParameter->_Zeta);
	if (_TerminalVec.size() == 3)
		permutationResult = FullCombination3(_pCoGAParameter->_Zeta);
	if (_TerminalVec.size() == 2)
		permutationResult = FullCombination2(_pCoGAParameter->_Zeta);
	std::vector<std::vector<Individual>>permutationIndividual;

	for (int spId = 0; spId < permutationResult[0].size(); spId++)
	{
		std::vector<Individual> individualVec;
		for (int indId = 0; indId < permutationResult.size(); indId++)
		{

			std::vector<int> tempVec = permutationResult[indId];
			//std::swap(tempVec[0], tempVec[spId]);
			Individual individual(speciesVec[spId][tempVec[spId]]);

			// initialize gene
			for (int i = 0; i < tempVec.size(); i++)
			{
				if (i != spId)
				{
					individual._Chromosome[i] = speciesVec[i][tempVec[i]]._Chromosome[i];
				}
			}
			individualVec.push_back(individual);
		}
		permutationIndividual.push_back(individualVec);
	}
 
	//std::vector<std::vector<Individual>>permutationIndividual;
	//for (int s = 0; s < _SpeciesVec.size(); s++)
	//{
	//	
	//	std::vector<Individual> vecTemp;
	//	for (int i = 0; i < _SpeciesVec[s]->_Populations.size(); i++)			
	//		vecTemp.push_back(*_SpeciesVec[s]->_Populations[i]);		
	//	permutationIndividual.push_back(vecTemp);			
	//}
	// 
 
	_LocalSearchTime =0.0;
	SaveChromosomePrice("Price_BeforeLocalSearch_.txt", permutationIndividual);
	time.Start();
	 
	 
	FindBestSolution(permutationIndividual);

	

	_LocalSearchTime += time.GetTimeInSecond();

	_CalculatationTime = _CoGAcalculatationTime + _LocalSearchTime;
	std::cout << "local search for the best solution \n";

}
void CoGA::Run1()
{
	TimeHelpers::Timer time;
	time.Start();
	_ToroidalGrid.SetParameter(_pCoGAParameter->_PopulationNum);
	InitProfit();
	std::cout << "initialize profit done \n";
	//InterativeLocalSearch();

	InitFitness();

	UpdateFitnessRecord();
	std::cout << "initialize fitness done \n";
	RandomInt randomIntSpecies(0, _TerminalVec.size() - 1);
	RandomInt randomIntIndividual(0, _pCoGAParameter->_PopulationNum - 1);
	int iteration = 0;
	//SaveContourmap(iteration+1, 0);
	bool  terminationflag = true;
	while (terminationflag)
	{

		if (iteration < _pCoGAParameter->_MaxIteration)
			terminationflag = true;
		else terminationflag = false;
		 _CoGAcalculatationTime += time.GetTimeInSecond();
		if (0== (iteration%100))
		{
			SaveChromosomePrice("Price_" + std::to_string(iteration) + ".txt");
		}
		time.Start(); 



		int speciecs_index = randomIntSpecies.GetInt();
		//int individualId = _SpeciesVec[speciecs_index]->WorseIndividualId();
		//int individualId = _SpeciesVec[speciecs_index]->BestIndividualId();
		int individualId = randomIntIndividual.GetInt();

		std::vector<int>  neighborhood = _ToroidalGrid.Neighborhood_3_3(individualId);
		std::vector<Individual> evolingNeighborhood = _SpeciesVec[speciecs_index]->GetIndividuals(neighborhood);


		std::pair<int, int> parentsId = PartensSelection(evolingNeighborhood);
		Individual father(_SpeciesVec[speciecs_index]->_Populations[parentsId.first]);
		Individual mother(_SpeciesVec[speciecs_index]->_Populations[parentsId.second]);
		std::pair<Individual, Individual>offsprings = CrossOver(father, mother, speciecs_index);
		Mutation(offsprings.first, speciecs_index);
		Mutation(offsprings.second, speciecs_index);

		/*for (int m = 0; m < neighborhood.size(); m++)
		{
		Mutation(speciecs_index, neighborhood[m]);
		}*/

		bool improvementFlag;
		std::pair<int, int> updateInidvidualIndexPair = _SpeciesVec[speciecs_index]->UpdatePopulation(offsprings, neighborhood, improvementFlag);


	
		//for offspring
		 
		UpdateProfit(speciecs_index, individualId);
		UpdateProfit(speciecs_index, updateInidvidualIndexPair.first);
		UpdateProfit(speciecs_index, updateInidvidualIndexPair.second);

		std::vector<int>  neighborhood1 = _ToroidalGrid.Neighborhood_3_3(updateInidvidualIndexPair.first);
		for (int n = 0; n < neighborhood1.size(); n++)
		{
			for (int specciesId = 0; specciesId < _TerminalVec.size(); specciesId++)
			{
				_SpeciesVec[specciesId]->UpdateFitness(neighborhood1[n]);
			}
		}

		std::vector<int>  neighborhood2 = _ToroidalGrid.Neighborhood_3_3(updateInidvidualIndexPair.second);
		for (int n = 0; n < neighborhood2.size(); n++)
		{
			for (int specciesId = 0; specciesId < _TerminalVec.size(); specciesId++)
			{
				_SpeciesVec[specciesId]->UpdateFitness(neighborhood2[n]);
			}
		}


		UpdateFitnessRecord();

		iteration++;
		std::cout << "main iteration " << iteration << std::endl;
		terminationflag = terminationflag && (! TerminationDeviation());
	}
	SaveChromosomePrice("Price_lastInteration" + std::to_string(iteration) + ".txt");
	//SaveContourmap(iteration+1, 0);
	//std::vector<std::vector<std::vector<double>>> chromosomeBakcup = BackUpChromosome();
	time.Start();
	std::vector<std::vector<Individual>> speciesVec;
	for (int s = 0; s < _SpeciesVec.size();s++)
	{
		std::vector<Individual> tempVec;
		for (int j = 0; j < _SpeciesVec[s]->_Populations.size();j++)
		{
			tempVec.push_back(*_SpeciesVec[s]->_Populations[j]);
		}
		
		ArraySort(tempVec, false);
		speciesVec.push_back(tempVec);
		
	}
	

	//std::vector<int> eleVec(5, 0);
	//std::iota(eleVec.begin(), eleVec.end(), 0);
	//Permutation<int> permutation(eleVec, 4);
	//std::vector<std::vector<int>> permutationResult = permutation.GetPermutationResult();
	std::vector<std::vector<int>>  permutationResult;
	if (_TerminalVec.size() == 6)
		permutationResult = FullCombination6(_pCoGAParameter->_Zeta);
	if (_TerminalVec.size() == 5)
		permutationResult = FullCombination5(_pCoGAParameter->_Zeta);
	if(_TerminalVec.size()==4) 
		permutationResult = FullCombination4(_pCoGAParameter->_Zeta);
	if (_TerminalVec.size() == 3)
		permutationResult = FullCombination3(_pCoGAParameter->_Zeta);
	if (_TerminalVec.size() == 2)
		permutationResult = FullCombination2(_pCoGAParameter->_Zeta);
	std::vector<std::vector<Individual>>permutationIndividual;
	
	for (int spId = 0; spId <permutationResult[0].size(); spId++)
	{
		std::vector<Individual> individualVec;
		for (int indId = 0; indId< permutationResult.size(); indId++)
		{
						
			std::vector<int> tempVec = permutationResult[indId];
			//std::swap(tempVec[0], tempVec[spId]);
			Individual individual(speciesVec[spId][tempVec[spId]]);
			
			// initialize gene
			for (int i = 0; i < tempVec.size(); i++)
			{
				if (i != spId)
				{
					individual._Chromosome[i] = speciesVec[i][tempVec[i]]._Chromosome[i];
				}
			}			
			individualVec.push_back(individual);
		}
		permutationIndividual.push_back(individualVec);
	}
	/*for (int indId = 0; indId < permutationIndividual.size(); indId++)
	{
		for (int spId = 0; spId < permutationIndividual[indId].size(); spId++)
		{
			permutationIndividual[indId][spId].PrintChromosome();
		}
	}*/
	//local search
	_LocalSearchTime += time.GetTimeInSecond();
	SaveChromosomePrice("Price_BeforeLocalSearch_.txt", permutationIndividual);
	time.Start();
 //	omp_set_num_threads(16);
#pragma omp parallel for collapse(2)
	{

		for (int spId = 0; spId < permutationIndividual.size(); spId++)
		
		{
 
	 


			for (int indId = 0; indId < permutationIndividual[spId].size(); indId++)
				{
					std::cout << "local search for " << indId << " " << spId << std::endl;
					InterativeLocalSearch(spId, permutationIndividual[spId][indId]);

				}
			 
		}
	}
	_LocalSearchTime += time.GetTimeInSecond();
	SaveChromosomePrice("Price_LocalSearch_.txt", permutationIndividual);
	time.Start();
	//SaveChromosomePrice("Price_LocalSearch_.txt");
	/*for (int indId = 0; indId < permutationIndividual.size(); indId++)
	{
		for (int spId = 0; spId < permutationIndividual[indId].size(); spId++)
		{
			permutationIndividual[indId][spId].PrintChromosome();
		}
	}*/
	//InterativeLocalSearch();
	//FindBestSolution();
	//FindBestSolution2();
	FindBestSolution(permutationIndividual);
	_LocalSearchTime += time.GetTimeInSecond();

	_CalculatationTime =  _CoGAcalculatationTime+_LocalSearchTime;
	std::cout << "local search for the best solution \n";
}
std::vector<std::vector<int>>  CoGA::FullCombination3(int M)
{
	std::vector<std::vector<int>> resultVec;
	for (int l_1 = 0; l_1 < M; l_1++)
	{

		for (int l_2 = 0; l_2 < M; l_2++)
		{
			for (int l_3 = 0; l_3 < M; l_3++)
			{

				//std::cout << l_1 << " ";				
				//std::cout << l_2 << " ";		
				//std::cout << l_3 << " ";
				//std::cout << l_4 << " ";
				//std::cout << "\n";	
				std::vector<int> tempVec;
				tempVec.push_back(l_1);
				tempVec.push_back(l_2);
				tempVec.push_back(l_3);
				resultVec.push_back(tempVec);
			}

		}

	}
	return resultVec;

}
std::vector<std::vector<int>>  CoGA::FullCombination2(int M)
{
	std::vector<std::vector<int>> resultVec;
	for (int l_1 = 0; l_1 < M; l_1++)
	{

		for (int l_2 = 0; l_2 < M; l_2++)
		{

			 
					//std::cout << l_1 << " ";				
					//std::cout << l_2 << " ";		
					//std::cout << l_3 << " ";
					//std::cout << l_4 << " ";
					//std::cout << "\n";	
					std::vector<int> tempVec;
					tempVec.push_back(l_1);
					tempVec.push_back(l_2);
					 
					resultVec.push_back(tempVec);
			 
		}

	}
	return resultVec;

}
std::vector<std::vector<int>>  CoGA::FullCombination6(int M)
{
	std::vector<std::vector<int>> resultVec;
	for (int l_1 = 0; l_1 < M; l_1++)
	{

		for (int l_2 = 0; l_2 < M; l_2++)
		{

			for (int l_3 = 0; l_3 < M; l_3++)
			{
				for (int l_4 = 0; l_4 < M; l_4++)
				{
					for (int l_5 = 0; l_5 < M; l_5++)
					{
						for (int l_6 = 0; l_6 < M; l_6++)
						{
							//std::cout << l_1 << " ";				
							//std::cout << l_2 << " ";		
							//std::cout << l_3 << " ";
							//std::cout << l_4 << " ";
							//std::cout << "\n";	
							std::vector<int> tempVec;
							tempVec.push_back(l_1);
							tempVec.push_back(l_2);
							tempVec.push_back(l_3);
							tempVec.push_back(l_4);
							tempVec.push_back(l_5);
							tempVec.push_back(l_6);
							resultVec.push_back(tempVec);
						}
					}
				}
			}
		}

	}
	return resultVec;
}
std::vector<std::vector<int>>  CoGA::FullCombination5(int M)
{
	std::vector<std::vector<int>> resultVec;
	for (int l_1 = 0; l_1 < M; l_1++)
	{

		for (int l_2 = 0; l_2 < M; l_2++)
		{

			for (int l_3 = 0; l_3 < M; l_3++)
			{
				for (int l_4 = 0; l_4 < M; l_4++)
				{
					for (int l_5 = 0; l_5 < M; l_5++)
					{
						
						
							//std::cout << l_1 << " ";				
							//std::cout << l_2 << " ";		
							//std::cout << l_3 << " ";
							//std::cout << l_4 << " ";
							//std::cout << "\n";	
							std::vector<int> tempVec;
							tempVec.push_back(l_1);
							tempVec.push_back(l_2);
							tempVec.push_back(l_3);
							tempVec.push_back(l_4);
							tempVec.push_back(l_5);
						
							resultVec.push_back(tempVec);
						
					}
				}
			}
		}

	}
	return resultVec;
}
std::vector<std::vector<int>>  CoGA::FullCombination4(int M)
{
	std::vector<std::vector<int>> resultVec;
	for (int l_1 = 0; l_1 < M; l_1++)
	{

		for (int l_2 = 0; l_2 < M; l_2++)
		{

			for (int l_3 = 0; l_3 < M; l_3++)
			{

				for (int l_4 = 0; l_4 < M; l_4++)
				{
					//std::cout << l_1 << " ";				
					//std::cout << l_2 << " ";		
					//std::cout << l_3 << " ";
					//std::cout << l_4 << " ";
					//std::cout << "\n";	
					std::vector<int> tempVec;
					tempVec.push_back(l_1);
					tempVec.push_back(l_2);
					tempVec.push_back(l_3);
					tempVec.push_back(l_4);
					resultVec.push_back(tempVec);
				}
			}
		}

	}
	return resultVec;

}
void CoGA::Run()
{
	 
		//Run1();
		Run2();
}
void  CoGA::UpdateProfit(int speciecs_index, int individualId)
{
	switch (_pCoGAParameter->_PartnerSelectionRule)
	{

	case PartnerSelectionRule::_PA :
		UpdateProfitPA(speciecs_index, individualId);
		break;
	case PartnerSelectionRule::_PB:
		UpdateProfitPB(speciecs_index, individualId);
		break;
	case PartnerSelectionRule::_PPF:
		UpdateProfitPPF(speciecs_index, individualId);
		break;
	case PartnerSelectionRule::_PPR:
		UpdateProfitPPR(  speciecs_index,   individualId);
		break;
	}
}
void CoGA::UpdateProfitPPR(int speciecs_index, int individualId)
{
	std::map<int, std::vector<Individual>> speciesIndividualMap;
	for (int specciesId = 0; specciesId < _TerminalVec.size(); specciesId++)
	{
		if (specciesId != speciecs_index)
		{
			std::vector<int> tempNeighborhood = PartnerSelection(individualId);
			std::vector<Individual> symbioticghborhood = _SpeciesVec[specciesId]->GetIndividuals(tempNeighborhood);
			std::vector<Individual>  bestPartner = SelectBestFitnessRandomly(symbioticghborhood, _pCoGAParameter->_PartnerNum);
			speciesIndividualMap.insert(std::pair<int, std::vector<Individual>>(specciesId, bestPartner));
		}
	}
	std::vector<double> sumProfitVec(_pCoGAParameter->_GeneNum, 0);
	//

	for (int p = 0; p < _pCoGAParameter->_PartnerNum; p++)
	{


		for (int s = 0; s < _SpeciesVec.size(); s++)
		{
			if (s != speciecs_index)
			{
				_SpeciesVec[speciecs_index]->_Populations[individualId]->_Chromosome[s] =
					speciesIndividualMap[s][p]._Chromosome[s];
			}
		}
		std::vector<double>tempProfitVec = CalculateProfit(speciecs_index, individualId);
		sumProfitVec = ArrayAdd(tempProfitVec, sumProfitVec);
	}
	for (int i = 0; i < sumProfitVec.size(); i++)
	{
		sumProfitVec[i] = sumProfitVec[i] / (1.0* _pCoGAParameter->_PartnerNum);
	}
	_SpeciesVec[speciecs_index]->_Populations[individualId]->_ProfitVec = sumProfitVec;

}
void CoGA::UpdateProfitPA(int speciecs_index, int individualId)
{
	std::map<int, std::vector<Individual>> speciesIndividualMap;
	int partnerNumber = 0;
	for (int specciesId = 0; specciesId < _TerminalVec.size(); specciesId++)
	{
		if (specciesId != speciecs_index)
		{
			std::vector<int> tempNeighborhood = PartnerSelection(individualId);
			std::vector<Individual> symbioticghborhood = _SpeciesVec[specciesId]->GetIndividuals(tempNeighborhood);			
			speciesIndividualMap.insert(std::pair<int, std::vector<Individual>>(specciesId, symbioticghborhood));
			partnerNumber = symbioticghborhood.size();
		}
	}
	std::vector<double> sumProfitVec(_pCoGAParameter->_GeneNum, 0);
	//

	for (int p = 0; p < partnerNumber; p++)
	{


		for (int s = 0; s < _SpeciesVec.size(); s++)
		{
			if (s != speciecs_index)
			{
				_SpeciesVec[speciecs_index]->_Populations[individualId]->_Chromosome[s] =
					speciesIndividualMap[s][p]._Chromosome[s];
			}
		}
		std::vector<double>tempProfitVec = CalculateProfit(speciecs_index, individualId);
		sumProfitVec = ArrayAdd(tempProfitVec, sumProfitVec);
	}
	for (int i = 0; i < sumProfitVec.size(); i++)
	{
		sumProfitVec[i] = sumProfitVec[i] / (1.0*  partnerNumber);
	}
	_SpeciesVec[speciecs_index]->_Populations[individualId]->_ProfitVec = sumProfitVec;

}
void CoGA::UpdateProfitPB(int speciecs_index, int individualId)
{
	std::map<int, Individual> speciesIndividualMap;
	for (int specciesId = 0; specciesId < _TerminalVec.size(); specciesId++)
	{
		if (specciesId != speciecs_index)
		{
			std::vector<int> tempNeighborhood = PartnerSelection(individualId);
			std::vector<Individual> symbioticghborhood = _SpeciesVec[specciesId]->GetIndividuals(tempNeighborhood);
			std::vector<Individual>  bestPartner = SelectBestFitnessRanking(symbioticghborhood,false);
			speciesIndividualMap.insert(std::pair<int, Individual>(specciesId, bestPartner[0]));
		}
	}
	 

	for (int s = 0; s < _SpeciesVec.size(); s++)
	{
		if (s != speciecs_index)
		{
				_SpeciesVec[speciecs_index]->_Populations[individualId]->_Chromosome[s] =
					speciesIndividualMap[s]._Chromosome[s];				
		}			
	}
	std::vector<double>tempProfitVec = CalculateProfit(speciecs_index, individualId);
 
	_SpeciesVec[speciecs_index]->_Populations[individualId]->_ProfitVec = tempProfitVec;

}
void  CoGA::UpdateProfitPPF(int speciecs_index, int individualId)
{
	 
	std::map<int, std::vector<Individual>> speciesIndividualMap;
	for (int specciesId = 0; specciesId < _TerminalVec.size(); specciesId++)
	{
		if (specciesId != speciecs_index)
		{
			std::vector<int> tempNeighborhood =  PartnerSelection(individualId); 
			std::vector<Individual> symbioticghborhood = _SpeciesVec[specciesId]->GetIndividuals(tempNeighborhood);
			std::vector<Individual>  bestPartner = SelectBestFitnessRouletteWheel(symbioticghborhood, _pCoGAParameter->_PartnerNum);
			speciesIndividualMap.insert(std::pair<int, std::vector<Individual>>(specciesId, bestPartner));
		}
	}
	std::vector<double> sumProfitVec(_pCoGAParameter->_GeneNum, 0);
	//
	
	for (int p = 0; p < _pCoGAParameter->_PartnerNum; p++)
	{


		for (int s = 0; s < _SpeciesVec.size(); s++)
		{
			if (s != speciecs_index)
			{
				_SpeciesVec[speciecs_index]->_Populations[individualId]->_Chromosome[s]=
				speciesIndividualMap[s][p]._Chromosome[s];
			}
		}
		std::vector<double>tempProfitVec=CalculateProfit(speciecs_index, individualId);
		sumProfitVec = ArrayAdd(tempProfitVec, sumProfitVec);
	}
	for (int i = 0; i < sumProfitVec.size();i++)
	{
		sumProfitVec[i] = sumProfitVec[i] / (1.0* _pCoGAParameter->_PartnerNum);
	}
	_SpeciesVec[speciecs_index]->_Populations[individualId]->_ProfitVec = sumProfitVec;

	
}
std::vector<std::vector<double>> CoGA::BackUpProfit()
{
	std::vector<std::vector<double>>  profitVec;
	std::vector< std::vector<std::vector<double>> > vec;
	for (int s = 0; s < _SpeciesVec.size(); s++)
	{
		std::vector<double> vec;
		for (int i = 0; i < _SpeciesVec[s]->_Populations.size(); i++)
		{
			vec.push_back(_SpeciesVec[s]->_Populations[i]->_Profit);
		}
		profitVec.push_back(vec);
	}
	return profitVec;
}
void CoGA::SetProfit(std::vector<std::vector<double>> &profitVec)
{
	for (int s = 0; s < _SpeciesVec.size(); s++)
	{ std::vector<double> vec;
		for (int i = 0; i < _SpeciesVec[s]->_Populations.size(); i++)
		{
			_SpeciesVec[s]->_Populations[i]->_Profit = profitVec[s][i];
		}
		 
	}
}

std::vector<std::vector<double>> CoGA::BackUpFitness()
{
	std::vector<std::vector<double>>  fitnessVec;
	std::vector< std::vector<std::vector<double>> > vec;
	for (int s = 0; s < _SpeciesVec.size(); s++)
	{
		std::vector<double> vec;
		for (int i = 0; i < _SpeciesVec[s]->_Populations.size(); i++)
		{
			vec.push_back(_SpeciesVec[s]->_Populations[i]->_Fitness);
		}
		fitnessVec.push_back(vec);
	}
	return fitnessVec;
}
void CoGA::SetFitness(std::vector<std::vector<double>>&fitnessVec)
{
	for (int s = 0; s < _SpeciesVec.size(); s++)
	{
		std::vector<double> vec;
		for (int i = 0; i < _SpeciesVec[s]->_Populations.size(); i++)
		{
			_SpeciesVec[s]->_Populations[i]->_Fitness = fitnessVec[s][i];
		}

	}
}
std::vector<std::vector<std::vector<double>>> CoGA::BackUpChromosome()
{
	std::vector< std::vector<std::vector<double>> > vec;
	for (int s = 0; s < _SpeciesVec.size(); s++)
	{
		std::vector<std::vector<double>> speciesVec;
		for (int i = 0; i < _SpeciesVec[s]->_Populations.size();i++)
		{
			speciesVec.push_back(std::vector<double>( _SpeciesVec[s]->_Populations[i]->_Chromosome ));
		}
		vec.push_back(speciesVec);
	}
	return vec;
}
void CoGA::SetChromosome(std::vector<std::vector<std::vector<double>>> &vec)
{
	for (int s = 0; s < _SpeciesVec.size(); s++)
	{
		 
		for (int i = 0; i < _SpeciesVec[s]->_Populations.size(); i++)
		{
			_SpeciesVec[s]->_Populations[i]->SetChromosome(vec[s][i]);
		}		
	}
}
std::vector<std::pair<int, int>> CoGA::IdenticalChoromosomeAmongSpecies()
{
	std::vector<std::pair<int, int>> indenticalVec;
	for (int speciesId = 0; speciesId < _SpeciesVec.size(); speciesId++)
	{
		std::vector<bool> populationFlagVec(_pCoGAParameter->_PopulationNum, false);

		int count = 0;
		for (int i = 0; i < _pCoGAParameter->_PopulationNum; i++)
		{

			std::vector<bool> flagVec(_SpeciesVec.size(), false);
			flagVec[speciesId] = true;
			for (int s = 0; s < _SpeciesVec.size(); s++)
			{
				if (i != s)
				{
					for (int j = 0; j < _pCoGAParameter->_PopulationNum; j++)
					{
						flagVec[s] = ArrayEqual(_SpeciesVec[speciesId]->_Populations[i]->_Chromosome,
							_SpeciesVec[s]->_Populations[i]->_Chromosome, 0.1);
						if (flagVec[s])
						{
							continue;
						}
					}
				}
			}
			bool flag = true;
			for (int s = 0; s < _SpeciesVec.size(); s++)
			{
				flag = flag & flagVec[s];
			}
			if (flag)
			{
				populationFlagVec[i] = true;
				count++;
				//std::cout << "find one individual " << i << std::endl;
			}
		}
		for (int i = 0; i < populationFlagVec.size(); i++)
		{
			if (populationFlagVec[i])
				indenticalVec.push_back(std::pair<int,int>(speciesId,i));
		}
	}
	
	return indenticalVec;
	
}
void CoGA::FindBestSolution()
{



	std::vector<std::pair<int, int>> identicalVec = IdenticalChoromosomeAmongSpecies();

	std::vector<int> speciesVec, individualVec;
	for (int i = 0; i < identicalVec.size();i++)
	{
		speciesVec.push_back(identicalVec[i].first);
		individualVec.push_back(identicalVec[i].second);
	}
	std::vector<std::vector<NonDominatedSortElement>> fontVec = FrontSorting(speciesVec, individualVec);
	std::cout << "fontVec.size() " << fontVec.size() << std::endl << std::endl;
	if (fontVec.size()>0)
	{
		double maxSumPorfit = std::numeric_limits<double>::min();
		for (int j = 0; j < fontVec[0].size(); j++)
		{			
			std::vector<double> profitVec = CalculateProfit(fontVec[0][j].m_SpeciesId, fontVec[0][j].m_IndividualId);
			double sum = ArraySum(profitVec);
			if (sum > maxSumPorfit)
			{
				int sepciesId = fontVec[0][j].m_SpeciesId;
				int individualId = fontVec[0][j].m_IndividualId;
				maxSumPorfit = sum;
				_BestSoltion = *_SpeciesVec[sepciesId]->_Populations[individualId];
				
			}
		}
	}
	 
	std::cout << "----------------------------\n";
	//std::cout << "individual in font  " << i << "\t" << fontVec[i].size() << std::endl;
	PrintSolution(_BestSoltion);
	std::vector<double> profitVec = CalculateProfit(_BestSoltion);
	int dominateFlag = 0;
	for (int i = 0; i < profitVec.size(); i++)
	{
		if (profitVec[i]> _BenchmarkSolution._ProfitVec[_TerminalVec[i]._Para._Name])
			dominateFlag++;
	}

	if (dominateFlag == profitVec.size())
		std::cout << "better then the benchmark solution\n";
	else
		std::cout << "worse then the benchmark solution\n";
}
void  CoGA::FindBestSolution(std::vector<std::vector<Individual>> individualVec)
{
	
	for (int i = 0; i < individualVec.size();i++)
	{
		for (int j = 0; j < individualVec[i].size(); j++)
		{
			individualVec[i][j]._ProfitVec = CalculateProfit(individualVec[i][j]);
			individualVec[i][j]._Profit = individualVec[i][j]._ProfitVec[i];
		}
		
	}
	int sid=Negotiation(individualVec);

	InterativeLocalSearch(sid, _BestSoltion._Index);
	_BestSoltion = *(_SpeciesVec[sid]->_Populations[_BestSoltion._Index]);
	std::cout << "----------------------------\n";
	//std::cout << "individual in font  " << i << "\t" << fontVec[i].size() << std::endl;
	PrintSolution(_BestSoltion);
	std::vector<double> profitVec = CalculateProfit(_BestSoltion);
	int dominateFlag = 0;
	for (int i = 0; i < profitVec.size(); i++)
	{
		if (profitVec[i]> _BenchmarkSolution._ProfitVec[_TerminalVec[i]._Para._Name])
			dominateFlag++;
	}

	if (dominateFlag == profitVec.size())
		std::cout << "better then the benchmark solution\n";
	else
		std::cout << "worse then the benchmark solution\n";
}
void CoGA::FindBestSolution2()
{

	/*

	//std::vector<std::pair<int, int>> identicalVec = IdenticalChoromosomeAmongSpecies();
	std::vector<std::pair<int, int>> identicalVec ;
	for (int s = 0; s < _TerminalVec.size();s++)
		for (int i = 0; i < _SpeciesVec[s]->_Populations.size();i++)	
			identicalVec.push_back(std::pair<int, int>(s, i));
	



	std::vector<int> speciesVec, individualVec;
	double maxSumPorfit = std::numeric_limits<double>::min();
	int bestSpeciesId = 0,bestIndividualId=0;
	for (int i = 0; i < identicalVec.size(); i++)
	{
		
		std::vector<double> profitVec = CalculateProfit(identicalVec[i].first, identicalVec[i].second);
		double sum = ArraySum(profitVec);
		if (sum > maxSumPorfit)
		{
			maxSumPorfit = sum;
			_BestSoltion.first = identicalVec[i].first;
			_BestSoltion.second = identicalVec[i].second;
		}
	}

	*/
	Negotiation();
	

	std::cout << "----------------------------\n";
	//std::cout << "individual in font  " << i << "\t" << fontVec[i].size() << std::endl;
	PrintSolution(_BestSoltion);
	std::vector<double> profitVec = CalculateProfit(_BestSoltion);
	int dominateFlag = 0;
	for (int i = 0; i < profitVec.size(); i++)
	{
		if (profitVec[i]> _BenchmarkSolution._ProfitVec[_TerminalVec[i]._Para._Name])
			dominateFlag++;
	}

	if (dominateFlag == profitVec.size())
		std::cout << "better then the benchmark solution\n";
	else
		std::cout << "worse then the benchmark solution\n";
}
/* Routine for usual non-domination checking
It will return the following values
1 if a dominates b
-1 if b dominates a
0 if both a and b are non-dominated */
int  CoGA::Dominance(std::vector<double>   obj1Vec, std::vector<double>   obj2Vec)
{

	int flag1 = 0, flag2 = 0;
	for (int i = 0; i < obj1Vec.size(); i++)
	{
		if (obj1Vec[i] > obj2Vec[i])
			{
				flag1 = 1;
			}
			else
			{
				if (obj1Vec[i] < obj2Vec[i] )
				{
					flag2 = 1;
				}
			}
				
	}
	if (flag1 == 1 && flag2 == 0)
		return 1;
	else
	{
		if (flag1 == 0 && flag2 == 1)
			return -1;
		else
			return 0;
	}
}

int  CoGA::IndividualDominance(std::pair<int, int> speciesId_IndividualId_1, std::pair<int, int> speciesId_IndividualId_2)
{
	int speciesId1 =speciesId_IndividualId_1.first;
	int inividual1 = speciesId_IndividualId_1.second;
	int speciesId2 = speciesId_IndividualId_2.first;
	int inividual2 = speciesId_IndividualId_2.second;
	std::vector<double> priceVec1 = _SpeciesVec[speciesId1]->_Populations[inividual1]->Decode(_pCoGAParameter->_PriceLowerBound, _pCoGAParameter->_PriceUpperBound);
	for (int i = 0; i < priceVec1.size(); i++)
	{
		_TerminalVec[i]._p = priceVec1[i];
	}
	std::vector<double> objVec1;
	for (int i = 0;i<_TerminalVec.size();i++)
	{
		NewtonRaphsonMethod(_TerminalVec, _SpeciesVec[i]->_PortPara);
		objVec1.push_back(Profit(_TerminalVec, i, _SpeciesVec[i]->_PortPara));
	}
	std::vector<double> priceVec2 = _SpeciesVec[speciesId2]->_Populations[inividual2]->Decode(_pCoGAParameter->_PriceLowerBound, _pCoGAParameter->_PriceUpperBound);
	for (int i = 0; i < priceVec2.size(); i++)
	{
		_TerminalVec[i]._p = priceVec2[i];
	}
	std::vector<double> objVec2;
	for (int i = 0; i < _TerminalVec.size(); i++)
	{
		NewtonRaphsonMethod(_TerminalVec, _SpeciesVec[i]->_PortPara);
		objVec2.push_back(Profit(_TerminalVec, i, _SpeciesVec[i]->_PortPara));
	}
	return Dominance(objVec1, objVec2);
}
std::vector<std::vector<NonDominatedSortElement>> CoGA::FrontSorting(std::vector<int> speciesIdVec, std::vector<int> individualList)
{
	std::vector<std::vector<int>> frontSet;
	std::vector<int> firstFront;
	std::vector<NonDominatedSortElement> nonDominatedSortElementList;
	
	for (int i; i<individualList.size(); i++)
		nonDominatedSortElementList.push_back(NonDominatedSortElement(speciesIdVec[i],individualList[i]));
	


	std::map<int, int> individualIdMap;
	for (int i = 0; i != individualList.size(); i++)
		individualIdMap.insert(std::pair<int, int>(individualList[i], i));
	
	for (int i = 0; i< individualList.size();  i++)
	{
		
		for (int j = i; j <individualList.size(); j++)
		{
			if (i != j)
			{
				int flag = IndividualDominance(std::pair<int, int>(speciesIdVec[i], individualList[i]), std::pair<int, int>(speciesIdVec[j], individualList[j]));				
				if (1 == flag)
				{
					nonDominatedSortElementList[i].m_DominatedElementId.push_back(j);
					nonDominatedSortElementList[j].m_DominatedByOtherIndividualNumber++;
				}
				else if (-1 == flag)
				{
					nonDominatedSortElementList[j].m_DominatedElementId.push_back(i);
					nonDominatedSortElementList[i].m_DominatedByOtherIndividualNumber++;
				}
			}
		}

	}
	for (int i = 0; i < nonDominatedSortElementList.size(); i++)
	if (0 == nonDominatedSortElementList[i].m_DominatedByOtherIndividualNumber)
	{
		firstFront.push_back(i);
	}
	frontSet.push_back(firstFront);
	while (firstFront.size()>0)
	{
		std::vector<int> currentFont;
		//std::vector<int>::iterator it = firstFront.begin();
		for (int i = 0; i < firstFront.size(); i++)
		{
			std::vector<int> vecIndividualIdVec = (nonDominatedSortElementList[firstFront[i]]).m_DominatedElementId;
			for (int j; j<vecIndividualIdVec.size(); j++)
			{
				int id = vecIndividualIdVec[j];
				nonDominatedSortElementList[id].m_DominatedByOtherIndividualNumber--;
				if (0 == nonDominatedSortElementList[id].m_DominatedByOtherIndividualNumber)
				{
					currentFont.push_back(id);
				}
			}
		}
		firstFront = currentFont;
		if (currentFont.size())
		{
			frontSet.push_back(currentFont);
		}
	}
	 
	std::vector<std::vector<NonDominatedSortElement>> resultFront;
	for (int i = 0; i < frontSet.size(); i++)
	{
		
		std::vector<NonDominatedSortElement> tempList;
		for (int j = 0; j < frontSet[i].size(); j++)
		{
			tempList.push_back(nonDominatedSortElementList[frontSet[i][j]]);
		}
		resultFront.push_back(tempList);
	}

	return resultFront;
}

bool CoGA::LocalSearch(int terimalId, int individualId, std::vector<double>& priceVec)
{
	priceVec.clear();
	priceVec = _SpeciesVec[terimalId]->_Populations[individualId]->Decode(_pCoGAParameter->_PriceLowerBound, _pCoGAParameter->_PriceUpperBound);
	for (int i = 0; i < _TerminalVec.size(); i++)
	{		
		_TerminalVec[i]._p = priceVec[i];
	}
	NewtonRaphsonMethod(_TerminalVec, _SpeciesVec[terimalId]->_PortPara);
	std::vector<double> profitVec1 = Profit(_TerminalVec, _SpeciesVec[terimalId]->_PortPara);
	std::vector<double> priceVecResult(priceVec);
	bool flag = false;
	int stepLength = _LSParameters._Length / _LSParameters._StepSize;
	stepLength = stepLength + stepLength;
	for (int step = 1; step <= stepLength; step++)
	{

		if (step < stepLength / 2)
		{
			_TerminalVec[terimalId]._p = priceVec[terimalId] - _LSParameters._StepSize*step;
		}
		else _TerminalVec[terimalId]._p = priceVec[terimalId] + _LSParameters._StepSize*(step - stepLength / 2);
		bool flag_lowerbound = _TerminalVec[terimalId]._p > _pCoGAParameter->_PriceLowerBound;
		bool flag_upperbound = _TerminalVec[terimalId]._p < _pCoGAParameter->_PriceUpperBound;
	    if (flag_lowerbound  &&
			flag_upperbound)
		{

			NewtonRaphsonMethod(_TerminalVec, _SpeciesVec[terimalId]->_PortPara);
			std::vector<double> profitVec2 = Profit(_TerminalVec, _SpeciesVec[terimalId]->_PortPara);
			/*if (Dominance(profitVec2, profitVec1) == 1)
			{
			flag = true;
			profitVec1 = profitVec2;
			priceVecResult = priceVec;
			priceVecResult[terimalId] = _TerminalVec[terimalId]._p;
			}*/
			if (profitVec2[terimalId]> profitVec1[terimalId])
			{
				flag = true;
				profitVec1 = profitVec2;
				priceVecResult = priceVec;
				priceVecResult[terimalId] = _TerminalVec[terimalId]._p;
			}
		}
		
	}
	priceVec = priceVecResult;
	return flag;
}

bool  CoGA::LocalSearch(int terimalId, Individual& individual, std::vector<double>& priceVec)
{
	
	std::vector<double> initpriceVec(priceVec);


	bool resultFlag = false;
	bool flag = true;
	while (flag)
	{
		flag = LocalSearch1(terimalId, individual, initpriceVec);
		if (flag)
		{
			resultFlag = true;
			priceVec = initpriceVec;
		}
	}
	return resultFlag;
}
bool  CoGA::LocalSearch1(int terimalId, Individual& individual, std::vector<double>& priceVec)
{
	
	for (int i = 0; i < _TerminalVec.size(); i++)
	{
		_TerminalVec[i]._p = priceVec[i];
	}
	NewtonRaphsonMethod(_TerminalVec, _SpeciesVec[terimalId]->_PortPara);
	std::vector<double> profitVec1 = Profit(_TerminalVec, _SpeciesVec[terimalId]->_PortPara);
	std::vector<double> priceVecResult(priceVec);
	bool flag = false;
	int stepLength = _LSParameters._Length / _LSParameters._StepSize;
	stepLength = stepLength + stepLength;
	for (int step = 1; step <= stepLength; step++)
	{

		if (step < stepLength / 2)
		{
			_TerminalVec[terimalId]._p = priceVec[terimalId] - _LSParameters._StepSize*step;
		}
		else _TerminalVec[terimalId]._p = priceVec[terimalId] + _LSParameters._StepSize*(step - stepLength / 2);
		bool flag_lowerbound = _TerminalVec[terimalId]._p > _pCoGAParameter->_PriceLowerBound;
		bool flag_upperbound = _TerminalVec[terimalId]._p < _pCoGAParameter->_PriceUpperBound;
		if (flag_lowerbound  &&
			flag_upperbound)
		{

			NewtonRaphsonMethod(_TerminalVec, _SpeciesVec[terimalId]->_PortPara);
			std::vector<double> profitVec2 = Profit(_TerminalVec, _SpeciesVec[terimalId]->_PortPara);
			double equalError = profitVec2[terimalId] - profitVec1[terimalId];
			if (equalError> 0.000001)			 
			{
				flag = true;
				profitVec1 = profitVec2;
				priceVecResult = priceVec;
				priceVecResult[terimalId] = _TerminalVec[terimalId]._p;
				 
			}
		}

	}
	priceVec = priceVecResult;
	return flag;
}
void CoGA::InterativeLocalSearch()
{
	//for (int i = 0; i < _SpeciesVec.size();i++)
//	{
		for (int j = 0; j < _pCoGAParameter->_PopulationNum; j++)
		{
			std::cout << "local search for " << j << std::endl;
			InterativeLocalSearch(j);

		}
	//}
}
 
void  CoGA::InterativeLocalSearch(int individualId)
{
	 
	
	
	for (int i = 0; i < _SpeciesVec.size();i++)
	{
		
		InterativeLocalSearch(i, individualId);
	}
	 
}
void  CoGA::InterativeLocalSearch(int terimalId, int individualId)
{
	InterativeLocalSearch(terimalId, *_SpeciesVec[terimalId]->_Populations[individualId]);
}
void CoGA::InterativeLocalSearch(int speciesId, Individual &individual)
{
	std::vector<double> initPriceVec  = individual.Decode(_pCoGAParameter->_PriceLowerBound, _pCoGAParameter->_PriceUpperBound);;
	std::vector<double> profitVec;

	int terimalId = speciesId;

	bool flag = true;

	std::vector<double>priceVec(initPriceVec);
	 
	while (flag)
	{		
		initPriceVec= priceVec ;
		flag = LocalSearch(terimalId, individual, initPriceVec);
		if (flag)
		{			 
			priceVec = initPriceVec;
		}else		
		{

			for (int count = 0; count< _TerminalVec.size(); count++)
			{
				initPriceVec = priceVec ;
				terimalId = (terimalId + 1) % _TerminalVec.size();
				bool tempflag  = LocalSearch(terimalId, individual, initPriceVec);
				if (tempflag)
				{
					flag = true;
					priceVec = initPriceVec ;										
				}
				
			}
		}
		terimalId = (terimalId + 1) % _SpeciesVec.size();
		//std::cout << "-------------------------------------local search \t" << terimalId<<"\n";
		//ArrayPrint(improvement);
	}
	individual.SetChromosome(priceVec, _pCoGAParameter->_PriceLowerBound, _pCoGAParameter->_PriceUpperBound);
	profitVec = CalculateProfit(individual);
	individual._ProfitVec = profitVec;
	individual._Profit = profitVec[speciesId];
	

}
std::vector<std::vector<double>>  CoGA::GetProfitMatchingAll(int speciesId)
{
	std::vector<std::vector<std::vector<double>>> chromosome =  BackUpChromosome();
	std::vector<std::vector<double>> profitBackup = BackUpProfit();
	

	std::vector<std::vector<double>> profitMat;
	for (int i = 0; i < _pCoGAParameter->_PopulationNum; i++)
	{
		std::vector<double> profitVec;
		for (int j = 0; j < _pCoGAParameter->_PopulationNum; j++)
		{
			// setup 
			for (int s = 0; s < _SpeciesVec.size();s++)
			{
				if (s!=speciesId)
				{
					_SpeciesVec[speciesId]->_Populations[i]->_Chromosome[s] = 
					_SpeciesVec[s]->_Populations[j]->_Chromosome[s];
				}
			}
			profitVec.push_back(CalculateProfit(speciesId, i)[speciesId]);
		}		
		profitMat.push_back(profitVec);
	}

	SetChromosome(chromosome);
	SetProfit(profitBackup);
	return profitMat;
}
Individual CoGA::SelectBestFitness(std::vector<Individual> vec)
{
	
		double maxFitness = vec[0]._Fitness;
		Individual bestIndividual(vec[0]);
		for (int i = 0; i < vec.size(); i++)
		{
			if (vec[i]._Fitness > maxFitness)
			{
				bestIndividual = vec[i];
				maxFitness = vec[i]._Fitness;
			}
		}
		return bestIndividual;
	
	/*else 
	{
		double maxFitness = std::numeric_limits<double>::min();
		Individual bestIndividual;
		for (int i = 0; i < vec.size(); i++)
		{
			if (vec[i]._Fitness > maxFitness)
			{
				bestIndividual = vec[i];
				maxFitness = vec[i]._Fitness;
			}
		}
		return bestIndividual;
	}*/
}
std::vector<Individual> CoGA::SelectBestFitnessRanking(std::vector<Individual> vec, bool asceding)
{
	std::vector<Individual> resultVec(vec);	
	ArraySort(resultVec, asceding);
	return resultVec;
}
std::vector<Individual> CoGA::SelectBestFitnessRandomly(std::vector<Individual> vec, int numberIndividual)
{
	std::vector<Individual> resultVec;

	RandomInt pro(0, vec.size() - 1);
	std::vector<int>indexVec;
	pro.GetArray(indexVec,numberIndividual);
	for (int i = 0; i < indexVec.size();i++)
	{
		resultVec.push_back(vec[indexVec[i]]);
	}
	
	return resultVec;
}
std::vector<Individual> CoGA::SelectBestFitnessRouletteWheel(std::vector<Individual> vec, int numberIndividual)
{
	std::vector<Individual> resultVec;
	
	std::vector<double> fitnessVec;
	for (int i = 0; i < vec.size(); i++)
	{		
		fitnessVec.push_back(vec[i]._Fitness);
	}
	int number = 0;
	while (number!=numberIndividual)
	{
		int id = RouletteSelect(fitnessVec);
		resultVec.push_back(vec[id]);
		number++;
	}
	return resultVec;
}
void  CoGA::PrintChromosome()
{
	for (int i = 0; i < _SpeciesVec.size();i++)
	{
		std::cout << "---------------------- species " << i << "--------------------" << std::endl;
		_SpeciesVec[i]->PrintChromosome();
	}
}
void   CoGA::PrintFitness()
{
	for (int i = 0; i < _SpeciesVec.size(); i++)
	{
		std::cout << "---------------------- species " << i << "--------------------" << std::endl;
		_SpeciesVec[i]->PrintFitness();
		std::cout <<std::endl;
	}
}
void  CoGA::InitFitness()
{
	for (int i = 0; i < _SpeciesVec.size(); i++)
		_SpeciesVec[i]->InitFitness();
	
}
void  CoGA::InitProfit()
{
	//switch (_pCoGAParameter->_Version)
	//{
	//case _Neighbor33FinalLocalSearch:
	//	for (int p = 0; p < _pCoGAParameter->_PopulationNum; p++)
	//	{
	//		for (int i = 0; i < _SpeciesVec.size(); i++)
	//		for (int j = 0; j < _SpeciesVec.size(); j++)
	//		if (i != j)
	//			_SpeciesVec[j]->_Populations[p]->_Chromosome[i] = _SpeciesVec[i]->_Populations[p]->_Chromosome[i];
	//		for (int i = 0; i < _SpeciesVec.size(); i++)
	//			_SpeciesVec[i]->CalculateProfit(p);
	//	}
	//	break;
	//case _NeighborLevelFinalLocalSearch:
	//	for (int p = 0; p < _pCoGAParameter->_PopulationNum; p++)
	//	{
	//		for (int i = 0; i < _SpeciesVec.size(); i++)
	//		for (int j = 0; j < _SpeciesVec.size(); j++)
	//		if (i != j)
	//			_SpeciesVec[j]->_Populations[p]->_Chromosome[i] = _SpeciesVec[i]->_Populations[p]->_Chromosome[i];
	//		for (int i = 0; i < _SpeciesVec.size(); i++)
	//			_SpeciesVec[i]->CalculateProfit(p);
	//	}
	//	break;
	//case _Neighbor33FitnessSum:
	//	for (int p = 0; p < _pCoGAParameter->_PopulationNum; p++)
	//	{
	//		for (int i = 0; i < _SpeciesVec.size(); i++)		
	//			UpdateProfitAverageMethod(i, p);
	//	}
	//	break;
	//default:
	//	break;
	//}

	for (int p = 0; p < _pCoGAParameter->_PopulationNum; p++)
	{
		 
		for (int i = 0; i < _SpeciesVec.size(); i++)
			for (int j = 0; j < _SpeciesVec.size(); j++)
				if (i != j)
					_SpeciesVec[j]->_Populations[p]->_Chromosome[i] = _SpeciesVec[i]->_Populations[p]->_Chromosome[i];
		for (int i = 0; i < _SpeciesVec.size(); i++)
			_SpeciesVec[i]->CalculateProfit(p);
		 
	}
}
void CoGA::SaveFitness(std::string fileName)
{
	std::ofstream ofs(fileName.c_str(), std::ios::out);
	if (ofs.is_open())
	{
		for (int p = 0; p < _pCoGAParameter->_PopulationNum; p++)
		{
			for (int i = 0; i < _SpeciesVec.size(); i++)
			{
				ofs << _SpeciesVec[i]->_Populations[p]->_Fitness <<"\t";
			}
			ofs << std::endl;
		}
		ofs.close();
	}
	else std::cout << "can not open " << fileName << std::endl;
	
	
}
void CoGA::SaveProfit(std::string fileName)
{
	std::ofstream ofs(fileName.c_str(), std::ios::out);
	if (ofs.is_open())
	{
		
		for (int s = 0; s < _SpeciesVec.size(); s++)
		{
			ofs<< std::fixed;
			ofs << "-----------------------------species "<<s <<"----------------------"<<std::endl;
			
			ofs << "-------------------------------------------------------------------" << std::endl;
			for (int p = 0; p < _pCoGAParameter->_PopulationNum; p++)
			{
				std::vector<double> priceVec = _SpeciesVec[s]->_Populations[p]->Decode(_pCoGAParameter->_PriceLowerBound,_pCoGAParameter->_PriceUpperBound);
				for (int i = 0; i < _TerminalVec.size(); i++)
					_TerminalVec[i]._p = priceVec[i];
				PortPara portPara;
				NewtonRaphsonMethod(_TerminalVec, portPara);
				std::vector<double> profitVec = Profit(_TerminalVec, portPara);
				std::vector<double> containerVec;
				for (int i = 0; i < _TerminalVec.size(); i++)
					containerVec.push_back(_TerminalVec[i]._x);
				ArraySave(priceVec, ofs);
				ofs << "\t\t";
				ArraySave(containerVec, ofs);
				ofs << "\t\t";
				ArraySave(profitVec, ofs);
				ofs << std::endl;
			}
			ofs << std::endl;
		}
		ofs.close();
	}
	else std::cout << "can not open " << fileName << std::endl;
}
void CoGA::SaveSearchRecordOfBestIndividual(std::string fileName)
{
	std::ofstream ofs(fileName.c_str(), std::ios::out);
	if (ofs.is_open())
	{
		for (int s = 0; s < _SpeciesVec.size(); s++)
		{
			ofs << std::fixed;
			ofs << "-----------------------------species " << s << "----------------------" << std::endl;
			
			ofs << "-----------------------------------best individual--------------------------------" << std::endl;
			{
				std::vector<double> priceVec = _SpeciesVec[s]->_BestIndividual->Decode(_pCoGAParameter->_PriceLowerBound, _pCoGAParameter->_PriceUpperBound);
				for (int i = 0; i < _TerminalVec.size(); i++)
					_TerminalVec[i]._p = priceVec[i];
				PortPara portPara;
				NewtonRaphsonMethod(_TerminalVec, portPara);
				std::vector<double> profitVec = Profit(_TerminalVec, portPara);
				std::vector<double> containerVec;
				for (int i = 0; i < _TerminalVec.size(); i++)
					containerVec.push_back(_TerminalVec[i]._x);
				ArraySave(priceVec, ofs);
				ofs << "\t\t";
				ArraySave(containerVec, ofs);
				ofs << "\t\t";
				ArraySave(profitVec, ofs);
				ofs << std::endl;
			}
			ofs << "price 1 \t price 2 \t price 3 \t price 4 \t container 1 \t container 2 \t container 3 \tcontainer 4 \t profit 1 \tprofit 2 \tprofit 3 \tprofit 4 \t" << std::endl;
			ofs << "-------------------------------------------------------------------" << std::endl;
			for (int p = 0; p < _SpeciesVec[s]->_BestIndividualRecord.size(); p++)
			{
				std::vector<double> priceVec = _SpeciesVec[s]->_BestIndividualRecord[p].Decode(_pCoGAParameter->_PriceLowerBound, _pCoGAParameter->_PriceUpperBound);
				for (int i = 0; i < _TerminalVec.size(); i++)
					_TerminalVec[i]._p = priceVec[i];
				PortPara portPara;
				NewtonRaphsonMethod(_TerminalVec, portPara);
				std::vector<double> profitVec = Profit(_TerminalVec, portPara);
				std::vector<double> containerVec;
				for (int i = 0; i < _TerminalVec.size(); i++)
					containerVec.push_back(_TerminalVec[i]._x);

				ArraySave(priceVec, ofs);
				ofs << "\t\t";
				ArraySave(containerVec, ofs);
				ofs << "\t\t";
				ArraySave(profitVec, ofs);
				ofs << std::endl;
			}
			ofs << std::endl;
		}
		ofs.close();
	}
	else std::cout << "can not open " << fileName << std::endl;
}
void CoGA::UpdateFitnessRecord()
{
	for (int i = 0; i < _SpeciesVec.size();i++)
	{
		_SpeciesVec[i]->UpdateFitnessSumList();
	}
	
}

void CoGA::SaveFitnessRecord(std::string fileName)
{
	std::ofstream ofs(fileName.c_str(), std::ios::out);
	if (ofs.is_open())
	{
		int length = _SpeciesVec[0]->_FitnessMeanDeviastionList.size();
		std::vector<std::list<std::pair<double,double>>::iterator> interVec;
		for (int i = 0; i < _SpeciesVec.size(); i++)
		{
			interVec.push_back(_SpeciesVec[i]->_FitnessMeanDeviastionList.begin());
		}

		for (int iter = 0; iter < length; iter++)
		{
			for (int i = 0; i < interVec.size(); i++)
			{
				ofs << interVec[i]->first << "\t" << interVec[i]->second << "\t";
				interVec[i]++;
			}
			ofs << std::endl;
		}

		ofs.close();
	}
}
std::vector<double> CoGA::CalculateProfit( Individual individual)
{
	std::vector<double> priceVec = individual.Decode(_pCoGAParameter->_PriceLowerBound, _pCoGAParameter->_PriceUpperBound);
	for (int i = 0; i < _TerminalVec.size(); i++)
		_TerminalVec[i]._p = priceVec[i];
	PortPara portPara;
	NewtonRaphsonMethod(_TerminalVec, portPara);
	std::vector<double> profitVec = Profit(_TerminalVec, portPara);
	return profitVec;
}
std::vector<double> CoGA::CalculateProfit(int peciesId, int individualId)
{
	std::vector<double> priceVec = _SpeciesVec[peciesId]->_Populations[individualId]->Decode(_pCoGAParameter->_PriceLowerBound, _pCoGAParameter->_PriceUpperBound);
	for (int i = 0; i < _TerminalVec.size(); i++)
		_TerminalVec[i]._p = priceVec[i];
	PortPara portPara;
	NewtonRaphsonMethod(_TerminalVec, portPara);
	std::vector<double> profitVec = Profit(_TerminalVec,portPara);
	return profitVec;
}
void CoGA::PrintSolution(int peciesId, int individualId)
{
	
	PrintSolution(_SpeciesVec[peciesId]->_Populations[individualId]);
	//ArrayPrint(priceVec);
	//ArrayPrint(containerVec);
	//ArrayPrint(profitVec);
}
void CoGA::PrintSolution(Individual individual)
{
	std::vector<double> priceVec = individual.Decode(_pCoGAParameter->_PriceLowerBound, _pCoGAParameter->_PriceUpperBound);
	for (int i = 0; i < _TerminalVec.size(); i++)
		_TerminalVec[i]._p = priceVec[i];
	PortPara portPara;
	NewtonRaphsonMethod(_TerminalVec, portPara);
	std::vector<double> profitVec = Profit(_TerminalVec, portPara);
	std::vector<double> containerVec;
	for (int i = 0; i < _TerminalVec.size(); i++)
		containerVec.push_back(_TerminalVec[i]._x);

	std::cout << "Total aggregate demand = " << X(_TerminalVec, portPara) << std::endl;
	std::cout << "LogSum = " << LogSum(_TerminalVec, portPara) << std::endl;
	std::cout << "name\t\tprice\t\tcontainer amount\tprofit\t\tuser cost\tmarket share \n";
	for (int i = 0; i < _TerminalVec.size(); i++)
	{
		std::cout << _TerminalVec[i]._Para._Name << "\t\t";
		std::cout << priceVec[i] << "\t\t";
		std::cout << containerVec[i] << "\t\t";
		std::cout << profitVec[i] << "\t\t";
		std::cout << OUC(_TerminalVec[i]) << "\t\t";
		std::cout << MarketShare(_TerminalVec, i, portPara) << std::endl;
	}


	std::cout << "Total profit " << ArraySum(profitVec) << std::endl;

}
void CoGA::PrintSolution(Individual *pindividual)
{
	PrintSolution(*pindividual);
}
void CoGA::SaveBestSolution(std::string fileName)
{
	std::ofstream ofs(fileName.c_str(), std::ios::out);
	if (ofs.is_open())
	{
		std::vector<double> priceVec = _BestSoltion.Decode(_pCoGAParameter->_PriceLowerBound, _pCoGAParameter->_PriceUpperBound);
		for (int i = 0; i < _TerminalVec.size(); i++)
			_TerminalVec[i]._p = priceVec[i];
		PortPara portPara;
		NewtonRaphsonMethod(_TerminalVec, portPara);
		std::vector<double> profitVec = Profit(_TerminalVec, portPara);
		std::vector<double> containerVec;
		for (int i = 0; i < _TerminalVec.size(); i++)
			containerVec.push_back(_TerminalVec[i]._x);

		ofs << "Total aggregate demand = " << X(_TerminalVec, portPara) << std::endl;
		ofs << "LogSum = " << LogSum(_TerminalVec, portPara) << std::endl;
		ofs << "name\t\tprice\t\tcontainer amount\tprofit\t\tuser cost\tmarket share \n";
		for (int i = 0; i < _TerminalVec.size(); i++)
		{
			ofs << _TerminalVec[i]._Para._Name << "\t\t";
			ofs << priceVec[i] << "\t\t";
			ofs << containerVec[i] << "\t\t";
			ofs << profitVec[i] << "\t\t";
			ofs << OUC(_TerminalVec[i]) << "\t\t";
			ofs << MarketShare(_TerminalVec, i, portPara) << std::endl;
		}


		ofs << "\n \n Total profit \t"<< ArraySum(profitVec)<<"\n\n";

		ofs << "\n benchmark improvement (Naima's paper)\n";
		 
	 
		for (int i = 0; i < profitVec.size(); i++)
		{
			ofs << 100.0*(profitVec[i] - _BenchmarkSolution._ProfitVec[_TerminalVec[i]._Para._Name]) / _BenchmarkSolution._ProfitVec[_TerminalVec[i]._Para._Name] << "\t";
		}
		ofs << std::endl;
		 

		/*ofs << "\nlocal search improvement\n";
		if (_LocalSearchImprovement.find(_BestSoltion) != _LocalSearchImprovement.end())
		{
			std::vector<double> vec =  _LocalSearchImprovement.find(_BestSoltion)->second;
			for (int i = 0; i < vec.size();i++)
			{
				ofs << vec[i] << "\t";
			}
			ofs << std::endl;
		}*/
		
		ofs << "\nLocalsearch calculation time  " <<_LocalSearchTime  << std::endl;
		ofs << "\ncoGA calculation time  " << _CoGAcalculatationTime << std::endl;
		ofs << "\nTotal calculation time  " << _CalculatationTime << std::endl;


		SaveAlgorithmParameters(ofs);
		ofs.close();
	}
}
void CoGA::SaveDominateBenchmarkSolution(std::string fileName)
{
	std::ofstream ofs(fileName.c_str(), std::ios::out);
	if (ofs.is_open())
	{
		
		ofs << "solution number in each species " << std::endl;

		ofs << "price 1 \t price 2 \t price 3 \t price 4 \t container 1 \t container 2 \t container 3 \tcontainer 4 \t profit 1 \tprofit 2 \tprofit 3 \tprofit 4 \t" << std::endl;
		ofs << "-------------------------------------------------------------------" << std::endl;
		ofs << std::fixed;
		std::vector<int> countVec;
		
		ofs << std::endl;
		for (int s = 0; s < _SpeciesVec.size(); s++)
		{		
			int count = 0;
			for (int p = 0; p < _SpeciesVec[s]->_Populations.size(); p++)
			{
				std::vector<double> priceVec = _SpeciesVec[s]->_Populations[p]->Decode(_pCoGAParameter->_PriceLowerBound, _pCoGAParameter->_PriceUpperBound);
				for (int i = 0; i < _TerminalVec.size(); i++)
					_TerminalVec[i]._p = priceVec[i];
				PortPara portPara;
				NewtonRaphsonMethod(_TerminalVec, portPara);
				std::vector<double> profitVec = Profit(_TerminalVec, portPara);
				std::vector<double> containerVec;
				for (int i = 0; i < _TerminalVec.size(); i++)
					containerVec.push_back(_TerminalVec[i]._x);
				int dominateFlag = 0;

				for (int i = 0; i < profitVec.size(); i++)
				{
					if (profitVec[i]> _BenchmarkSolution._ProfitVec[_TerminalVec[i]._Para._Name])
						dominateFlag ++;
				}
					
				if (dominateFlag == profitVec.size())
				{
					ArraySave(priceVec, ofs);
					ofs << "\t\t";
					ArraySave(containerVec, ofs);
					ofs << "\t\t";
					ArraySave(profitVec, ofs);
					ofs << std::endl;
					count++;
				}				
			}
			countVec.push_back(count);
			ofs << std::endl;
		}


		for (int s = 0; s < countVec.size(); s++)
		{
			ofs << countVec[s] << "\t";
		}
		ofs << std::endl;
		ofs.close();
	}
	else std::cout << "can not open " << fileName << std::endl;
}

void   CoGA::SaveContourmap(int iteration,  int speciesId)
{
	std::string fileName("Contourmap_");
	fileName += std::to_string(iteration);
	fileName += "_";
	fileName += std::to_string(speciesId);
	fileName += ".txt";
	std::vector<std::vector<double>>contourMat = GetProfitMatchingAll(speciesId);
	SaveContourmap(fileName, contourMat);
}
void  CoGA::SaveContourmap(std::string fileName, const std::vector<std::vector<double>>& contourMat)
{
	std::ofstream ofs(fileName.c_str(), std::ios::out);
	if (ofs.is_open())
	{

		for (int i = 0; i < contourMat.size(); i++)
		{
			for (int j = 0; j < contourMat[i].size(); j++)
			{
				ofs << contourMat[i][j] << "\t";
			}
			ofs << std::endl;
		}
		ofs.close();
	}
	else std::cout << "can not open file "<<fileName.c_str() << std::endl;
}
void CoGA::SaveNeighborLevel(std::string fileName)
{
	std::ofstream ofs(fileName.c_str(), std::ios::out);
	if (ofs.is_open())
	{
		for (int p = 0; p < _pCoGAParameter->_PopulationNum; p++)
		{
			for (int s = 0; s < _SpeciesVec.size(); s++)
			{							
				ofs << _SpeciesVec[s]->_Populations[p]->_NeighborLevel<< " ";		
			}
			ofs << "\n";
		}
		ofs.close();
	}
	else std::cout << "can not open file " << fileName.c_str() << std::endl;
}
void  CoGA::SaveAlgorithmParameters(std::string fileName)
{
	std::ofstream ofs(fileName.c_str(), std::ios::out);
	if (ofs.is_open())
	{
		SaveAlgorithmParameters(ofs);
		
		ofs.close();
	}
	else std::cout << "can not open file " << fileName.c_str() << std::endl;
}
void CoGA::SaveAlgorithmParameters(std::ofstream &ofs)
{

	ofs << "---------------------------------------------------------------------" << std::endl;
	
	ofs << "Probability of mutation : " << _pCoGAParameter->_ProMutation << std::endl;
	ofs << "Probability of crossover : " << _pCoGAParameter->_ProCrossover << std::endl;
	ofs << "Maximum iteration : " << _pCoGAParameter->_MaxIteration << std::endl;
	ofs << "Population size : " << _pCoGAParameter->_PopulationNum << std::endl;
	ofs << "Gene size : " << _pCoGAParameter->_GeneNum << std::endl;
	ofs << "Lower bound of price : " << _pCoGAParameter->_PriceLowerBound << std::endl;
	ofs << "Upper bound of price : " << _pCoGAParameter->_PriceUpperBound << std::endl;
	ofs << "Parent selection method : " << _pCoGAParameter->_ParentSelectionPara << std::endl;
	ofs << "Crossover method : " << _pCoGAParameter->_CrossOverPara << std::endl;
	ofs << "Mutation method : " << _pCoGAParameter->_MutationPara << std::endl;
	ofs << "Fitness weight : " << _pCoGAParameter->_FitnessWeight << std::endl;

	ofs << "Local search step length : " << _LSParameters._Length << std::endl;
	ofs << "Local search step size : " << _LSParameters._StepSize << std::endl;

	
	SaveVersion(ofs);
}
void  CoGA::SaveChromosomePrice(std::string fileName,std::vector<std::vector<Individual>> individualMat)
{

	std::ofstream ofs(fileName.c_str(), std::ios::out);
	if (ofs.is_open())
	{
		
		for (int p = 0; p < individualMat[0].size(); p++)
		{
			for (int s = 0; s < individualMat.size(); s++)
			{
				std::vector<double> priceVec = individualMat[s][p].Decode(_pCoGAParameter->_PriceLowerBound, _pCoGAParameter->_PriceUpperBound);
				/*for (int i = 0; i < _SpeciesVec[s]->_Populations[p]->_Chromosome.size(); i++)
				{
				ofs << _SpeciesVec[s]->_Populations[p]->_Chromosome[i] << " ";
				}*/
				for (int i = 0; i < priceVec.size(); i++)
				{
					ofs << priceVec[i] << " ";
				}
				std::vector<double> profitVec = CalculateProfit(individualMat[s][p]);
				for (int i = 0; i < profitVec.size(); i++)
				{
					ofs << profitVec[i] << " ";
				}



			}
			ofs << "\n";
		}

		ofs.close();
	}
	else std::cout << "can not open file " << fileName.c_str() << std::endl;
}
void  CoGA::SaveChromosomePrice(std::string fileName)
{

	std::ofstream ofs(fileName.c_str(), std::ios::out);
	if (ofs.is_open())
	{
		for (int p = 0; p < _pCoGAParameter->_PopulationNum; p++)
		{
			for (int s = 0; s < _SpeciesVec.size(); s++)
			{
				std::vector<double> priceVec = _SpeciesVec[s]->_Populations[p]->Decode(_pCoGAParameter->_PriceLowerBound, _pCoGAParameter->_PriceUpperBound);
				/*for (int i = 0; i < _SpeciesVec[s]->_Populations[p]->_Chromosome.size(); i++)
				{
				ofs << _SpeciesVec[s]->_Populations[p]->_Chromosome[i] << " ";
				}*/
				for (int i = 0; i < priceVec.size(); i++)
				{
					ofs << priceVec[i] << " ";
				}
				std::vector<double> profitVec = CalculateProfit(s, p);
				for (int i = 0; i < profitVec.size(); i++)
				{
					ofs << profitVec[i] << " ";
				}
				 
					 
				 				
			}
			ofs << "\n";
		}

		ofs.close();
	}
	else std::cout << "can not open file " << fileName.c_str() << std::endl;
}
void CoGA::SaveChromosome(std::string fileName)
{

	std::ofstream ofs(fileName.c_str(), std::ios::out);
	if (ofs.is_open())
	{				
		for (int p = 0; p < _pCoGAParameter->_PopulationNum; p++)
		{
			for (int s = 0; s < _SpeciesVec.size(); s++)
			{
				std::vector<double> priceVec = _SpeciesVec[s]->_Populations[p]->Decode(_pCoGAParameter->_PriceLowerBound, _pCoGAParameter->_PriceUpperBound);
				/*for (int i = 0; i < _SpeciesVec[s]->_Populations[p]->_Chromosome.size(); i++)
				{
					ofs << _SpeciesVec[s]->_Populations[p]->_Chromosome[i] << " ";
				}*/
				for (int i = 0; i < priceVec.size(); i++)
				{
					ofs << priceVec[i] << " ";
				}
				std::vector<double> profitVec = CalculateProfit(s,p);
				for (int i = 0; i < profitVec.size(); i++)
				{
					ofs << profitVec[i] << " ";
				}
				ofs << ArraySum(profitVec) << " ";
				ofs << _SpeciesVec[s]->_Populations[p]->_Fitness << " ";
			}
			ofs << "\n";
		}
		
		
		ofs.close();
	}
	else std::cout << "can not open file " << fileName.c_str() << std::endl;
}
int CoGA::Negotiation(std::vector<std::vector<Individual>> individualVec)
{
	_SBP._pCoGAParameter = _pCoGAParameter;
	_SBP.InitSolutionPool(individualVec);
	if (_SBP.Negotiation())
	{
		 

		int speciesId = _SBP._SpeciesIndividualId.first;
		int individualId = _SBP._SpeciesIndividualId.second;
		_BestSoltion = individualVec[speciesId][individualId];
		std::cout << "Negotiation success \n";
		return  speciesId ;
	}
}
//return Species id
int CoGA::Negotiation()
{
	
	_SBP._pCoGAParameter = _pCoGAParameter;
	_SBP.InitSolutionPool(_SpeciesVec);
	if (_SBP.Negotiation())
	{
		int speciesId = _SBP._SpeciesIndividualId.first;
		int individualId = _SBP._SpeciesIndividualId.second;
		 
		_BestSoltion =* _SpeciesVec[speciesId]->_Populations[individualId];
		std::cout << "Negotiation success \n";
		return  speciesId ;
	}
	
}
bool  CoGA::TerminationDeviation()
{
	bool flag = true;
	std::cout << "-------------------- ";
	for (int s = 0; s < _SpeciesVec.size();s++)
	{
		double dev = _SpeciesVec[s]->ChromosomeDeviation();
		//std::cout <<dev <<" ";
		if (dev > _pCoGAParameter->_Psi)
			return false;
	
	}

	std::cout << std::endl;
	return true;
	
}
void CoGA::PrintVersion()
{
	std::cout << "--------------------------------------version-------------------------------------------\n";
	std::cout << "Scope of partners to be used for evaluation of fitness value of a chromosome\n";
	if (_pCoGAParameter->_ScopeofPartners == ScopeofPartners::_SE)
	{
		std::cout << "\t\t\t_SE: Entire population \n";
	}
	if (_pCoGAParameter->_ScopeofPartners == ScopeofPartners::_SN)
	{
		std::cout << "\t\t\t_SE: 3*3 Neighborhood \n";
	}
	std::cout << "Partner selection rule for evaluating the fitness value\n";
	if (_pCoGAParameter->_PartnerSelectionRule == PartnerSelectionRule::_PA)
	{
		std::cout << "\t\t\t_PA: All the partners in the scope and using the average value \n";
	}
	if (_pCoGAParameter->_PartnerSelectionRule == PartnerSelectionRule::_PB)
	{
		std::cout << "\t\t\t_PB: The best partner in the scope \n";
	}
	if (_pCoGAParameter->_PartnerSelectionRule == PartnerSelectionRule::_PPR)
	{
		std::cout << "\t\t\t_PPR: A part of partners in the scope in a random way  \n";
	}
	if (_pCoGAParameter->_PartnerSelectionRule == PartnerSelectionRule::_PPF)
	{
		std::cout << "\t\t\t_PPF: A part of partners in the scope based on their fitness value  \n";
	}	 
	std::cout << "---------------------------------------------------------------------------------------\n";
}
void CoGA::SaveVersion(std::ostream &ofs)
{
	ofs << "--------------------------------------version-------------------------------------------\n";
	ofs << "Scope of partners to be used for evaluation of fitness value of a chromosome\n";
	if (_pCoGAParameter->_ScopeofPartners == ScopeofPartners::_SE)
	{
		ofs << "\t\t\t_SE: Entire population \n";
	}
	if (_pCoGAParameter->_ScopeofPartners == ScopeofPartners::_SN)
	{
		ofs << "\t\t\t_SE: 3*3 Neighborhood \n";
	}
	std::cout << "Partner selection rule for evaluating the fitness value\n";
	if (_pCoGAParameter->_PartnerSelectionRule == PartnerSelectionRule::_PA)
	{
		ofs << "\t\t\t_PA: All the partners in the scope and using the average value \n";
	}
	if (_pCoGAParameter->_PartnerSelectionRule == PartnerSelectionRule::_PB)
	{
		ofs << "\t\t\t_PB: The best partner in the scope \n";
	}
	if (_pCoGAParameter->_PartnerSelectionRule == PartnerSelectionRule::_PPR)
	{
		ofs << "\t\t\t_PPR: A part of partners in the scope in a random way  \n";
	}
	if (_pCoGAParameter->_PartnerSelectionRule == PartnerSelectionRule::_PPF)
	{
		ofs << "\t\t\t_PPF: A part of partners in the scope based on their fitness value  \n";
	}
	ofs << "---------------------------------------------------------------------------------------\n";
}