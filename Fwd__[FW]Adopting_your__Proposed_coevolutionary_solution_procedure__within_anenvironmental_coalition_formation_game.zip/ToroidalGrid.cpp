#include"ToroidalGrid.h"
#include<cmath>
#include <algorithm>
#include <numeric>
ToroidalGrid::ToroidalGrid()
{

}
ToroidalGrid::ToroidalGrid(int eleNum)
{
	SetParameter(eleNum);
}
void ToroidalGrid::SetParameter(int eleNum)
{
	_ElementNum = eleNum;
	_RowNum = std::sqrt(eleNum);
	_ColNum = eleNum / _RowNum;
	_MaxLevel = std::max(_RowNum - 1, _ColNum - 1) / 2;
}
std::vector<int> ToroidalGrid::Neighborhood_3_3(int eleIndex)
{

	return Neighborhood_3_3(Index(eleIndex).first, Index(eleIndex).second);
}
std::vector<int> ToroidalGrid::Neighborhood_3_3(int row, int col)
{
	std::vector<int> vec;
	int r, c;
	//left upper
	r = row - 1;
	if (r<0)
		r += _RowNum;
	c = col - 1;
	if (c<0)
		c += _ColNum;
	vec.push_back(Index(r, c));
	//upper
	r = row - 1;
	if (r<0)
		r += _RowNum;
	c = col;
	vec.push_back(Index(r, c));
	//right upper
	r = row - 1;
	if (r<0)
		r += _RowNum;
	c = col + 1;
	if (c >= _ColNum)
		c %= _ColNum;
	vec.push_back(Index(r, c));
	//left
	r = row;
	c = col - 1;
	if (c<0)
		c += _ColNum;
	vec.push_back(Index(r, c));
	// center 
	vec.push_back(Index(row, col));
	//right
	r = row;
	c = col + 1;
	if (c >= _ColNum)
		c %= _ColNum;
	vec.push_back(Index(r, c));
	//left down
	r = row + 1;
	if (r >= _RowNum)
		r %= r / _RowNum;
	c = col - 1;
	if (c<0)
		c += _ColNum;
	vec.push_back(Index(r, c));
	//down
	r = row + 1;
	if (r >= _RowNum)
		r %= r / _RowNum;
	c = col;
	vec.push_back(Index(r, c));
	//right down
	r = row + 1;
	if (r >= _RowNum)
		r %= r / _RowNum;
	c = col + 1;
	if (c >= _ColNum)
		c %= _ColNum;
	vec.push_back(Index(r, c));
	return vec;
}
int ToroidalGrid::Index(int row, int col)
{
	int index;
	index = row *_ColNum + col;
	return index;
}
std::pair<int, int> ToroidalGrid::Index(int eleIndex)
{
	std::pair<int, int> p;
	p.first = eleIndex / _ColNum;
	p.second = eleIndex%_ColNum;
	return p;
}

std::vector<int> ToroidalGrid::HorizontalNeighborhood(int row, int col, int neighborNum)
{
	std::vector<int> indexVec;
	int leftNeiborNum = neighborNum;
	int rightNeiborNum = leftNeiborNum;
	for (int i = 1; i <= leftNeiborNum;i++)
	{
		int tempCol = col - i;
		tempCol = tempCol + _ColNum;
		tempCol = tempCol % _ColNum;
		indexVec.push_back(Index(row, tempCol));
	}
	indexVec.push_back(Index(row, col));
	for (int i = 1; i <= rightNeiborNum; i++)
	{
		int tempCol = col + i;		
		tempCol = tempCol % _ColNum;
		indexVec.push_back(Index(row, tempCol));
	}
	return indexVec;
}
std::vector<int> ToroidalGrid::VerticalNeighborhood(int row, int col, int neighborNum)
{
	std::vector<int> indexVec;
	int upperNeiborNum = neighborNum;
	int downNeiborNum = upperNeiborNum;
	for (int i = 1; i <= upperNeiborNum; i++)
	{
		int tempRow = row - i;
		tempRow = tempRow + _RowNum;
		tempRow = tempRow % _RowNum;
		indexVec.push_back(Index(tempRow, col));
	}
	indexVec.push_back(Index(row, col));
	for (int i = 1; i <= downNeiborNum; i++)
	{
		int tempRow = row + i;
		tempRow = tempRow % _RowNum;
		indexVec.push_back(Index(tempRow, col));
	}
	return indexVec;
}
std::vector<int> ToroidalGrid::NeighborhoodLevel(int level, int eleIndex)
{
	
	if (level < _MaxLevel)
	{
		std::vector<int> neighborIdexVec;
		std::pair<int, int> centerId = Index(eleIndex);
		std::vector<int> verticalNeighborVec = VerticalNeighborhood(centerId.first, centerId.second, level);
		for (int i = 0; i < verticalNeighborVec.size(); i++)
		{
			std::pair<int, int> rowcol = Index(verticalNeighborVec[i]);
			std::vector<int> horNeighborVec = HorizontalNeighborhood(rowcol.first, rowcol.second, level);
			for (int j = 0; j < horNeighborVec.size(); j++)
			{
				neighborIdexVec.push_back(horNeighborVec[j]);
			}
		}
		return neighborIdexVec;
	}
	else
	{
		std::vector<int> neighborIdexVec(_ElementNum);
		std::iota(neighborIdexVec.begin(), neighborIdexVec.end(), 0);
		return neighborIdexVec;
	}
	
}
std::vector<int> ToroidalGrid::EntireNeighbor()// selection all the elements
{
	std::vector<int> neighborVec(_ElementNum);
	std::iota(neighborVec.begin(), neighborVec.end(), 0);
	return neighborVec;
}