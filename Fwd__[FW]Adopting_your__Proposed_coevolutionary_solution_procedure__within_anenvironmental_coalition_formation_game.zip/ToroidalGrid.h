#ifndef TOROIDALGRID_H
#define TOROIDALGRID_H
#include<vector>
class ToroidalGrid
{
public:
	ToroidalGrid();
	ToroidalGrid(int eleNum);
public:
	void SetParameter(int eleNum);
	std::vector<int> Neighborhood_3_3(int eleIndex);	 
	std::vector<int> Neighborhood_3_3(int row, int col);
	int Index(int row, int col);
	std::pair<int, int> Index(int eleIndex);
	std::vector<int> HorizontalNeighborhood(int row, int col, int neighborNum);
	std::vector<int> VerticalNeighborhood(int row, int col, int neighborNum);
	std::vector<int> NeighborhoodLevel(int level,int eleIndex);
	std::vector<int> EntireNeighbor();// selection all the elements
private:
	int _ElementNum;
	int _RowNum;
	int _ColNum;
public:
	int _MaxLevel;
};
#endif